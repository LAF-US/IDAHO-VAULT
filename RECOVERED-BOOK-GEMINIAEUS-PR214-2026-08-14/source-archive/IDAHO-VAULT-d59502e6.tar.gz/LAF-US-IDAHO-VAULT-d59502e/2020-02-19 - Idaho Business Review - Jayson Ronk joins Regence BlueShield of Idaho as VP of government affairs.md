---
related:
- Boise
- Boise State University
- Building Contractors Association of Southwest Idaho
- C.L. 'Butch' Otter
- Department of Insurance
- Idaho
- Idaho Republican Party
- Idaho State University
- Jayson Ronk
- Micron Technology
- election
authority: LOGAN
---
Jayson Ronk has joined Regence as its first vice president of government affairs. In this role, Ronk will oversee all Idaho intergovernmental relations activities, including those with the executive branch, Legislature and Department of Insurance, while also overseeing business liaison efforts.

Ronk has been actively engaged in the Idaho business and political arena for more than 17 years with a variety of corporate, association and political employers. Most recently, he was state government affairs director with Micron Technology. Prior to that, Ronk managed then-Gov. C.L. 'Butch' Otter’s re-election campaign for a third consecutive term. Before that, Ronk was vice president of the Idaho Association of Commerce & Industry (IACI). Ronk also served as executive director of the Idaho Republican Party and worked as government affairs director of the Building Contractors Association of Southwest Idaho.

Ronk holds a bachelor’s degree in political science from Idaho State University and a master’s degree in public administration from Boise State University.