---
author:
- Anne Helen Petersen
outlet:
- Buzzfeed News
URL: https://www.buzzfeednews.com/article/annehelenpetersen/coronavirus-covid-cities-second-homes-rural-small-towns
related:
- '187'
- '200'
- '250'
- '500'
- Anne Helen Petersen
- Banks
- Blaine County
- Boise
- Colorado
- Connecticut
- Facebook
- Grangeville
- ICU
- Idaho
- Idaho Statesman
- Lake
- Maine
- Medicaid
- Missoula
- Montana
- Netflix
- New York
- North Carolina
- North Idaho
- OUT
- Oregon
- Portland
- San Francisco
- Seattle
- Summit County
- Sun Valley
- Texas
- Twitter
- Utah
- Washington
- Wyoming
- affordable housing
- airport
- apartments
- broadband
- chain
- children
- cities
- connections
- coronavirus
- counties
- dollars
- economic development
- emergency room
- fishing
- flooding
- health care
- homes
- hospitals
- housing
- infrastructure
- nurses
- parents
- police
- self
- sign
- ski resorts
- social media
- systems
- taxes
- teachers
- water
- window
authority: LOGAN
---
*You might not want to spend your quarantine in a city. But the rural places many Americans treat as playgrounds, and the workers who keep them running, will suffer for it.*

“Wealth is the vector.” That’s what sociologist Tressie McMillan Cottom tweeted last week, in reference to the spread of COVID-19 across both the globe and the United States. Wealth is not the cause of every concentrated outbreak dotting the United States. But it’s the common denominator of so much of its spread outside of major urban areas. It’s the reason why so many of the coronavirus hot spots in the Mountain West — Sun Valley, Idaho; Gunnison County, Colorado; Summit County, Utah; Gallatin County, Montana — overlap with winter playgrounds for the wealthy. The virus travels via people, and the people who travel the most, both domestically and internationally, are rich people.

A party in the tony bedroom community of Westport, Connecticut, all the way back on March 5, became what one epidemiologist referred to as a “super-spreading event,” with infected attendees dispersing throughout Connecticut and New England, and one party-goer falling ill on a plane ride back to South Africa. In Idaho’s Blaine County, home to Sun Valley, more than half of the residential properties are second homes or rental properties, and more than 30,000 people fly into the regional airport during ski season alone. As of March 31, 187 people in the county of 22,000 have tested positive, including local emergency room physician Brent Russell. Two people have died. The town’s small hospital has two ICU beds and a single ventilator.

“People come here from all over the world,” Russell told the Idaho Statesman. “Especially this time of year. When I’m in the ER, I get people from New York, Washington D.C., San Francisco, Seattle. Every week there’s people from those places. Most likely someone from an urban area or multiple people from urban areas came here and they just set it off.”

All over the United States, people are fleeing urban areas with high infection rates for the perceived safety and natural beauty of rural areas. Some of them own second homes in those areas; others are paying upwards of $10,000 a month, depending on the area, for temporary housing. The common denominator among those populations is, again, wealth — either their own or their families’. They can flee the city because their jobs can be done remotely, or they don’t work at all. They either had a vacation house already, or they can afford to fork over what amounts to a second rent, or second mortgage.

Not everyone leaving a big city because of the pandemic is heading for a vacation home; many people with mobile jobs are relocating to stay with family in suburban and rural hometowns. And many of the rural places that will eventually be hardest hit by the coronavirus are not upscale ski and beach towns, but small and often poor communities that have no tourist economy — or any of the infrastructure that comes with it. The resort areas seeing an influx of potentially virus-carrying city dwellers now are a kind of canary in the coal mine: a preview of how desperately overwhelmed rural areas across the country will be by the coronavirus, whenever it arrives.

From the coast of Maine to the North Shore of Lake Superior, hundreds of thousands of people have either already arrived or are scrambling to find vacant rentals. Some are taking precautions when they leave their primary dwellings, fully isolating themselves for 14 days or more in their new, temporary towns, as the White House has recommended for anyone leaving New York City. But many, presumably, are not.

For now, in the absence of any clear federal guidelines restricting domestic travel, residents in many small towns across the US are drafting their own ad hoc policies for outside visitors. In Skamania County, outside of Portland, there are signs spray-painted with “STAY OUT LOCALS ONLY” posted around town. One resident told me that community members will follow around any car they don’t recognize that enters the neighborhood. (The local hardware store is also offering free toilet paper with the purchase of a firearm.) At a small backwoods inn on the banks of the Rogue River in Oregon, 200 miles from the nearest hospital, the owner told me that even with a “NO VACANCY” sign up, and the restaurant closed down, she still had people knocking on the door, looking for a long-term place to stay.

In Dare County, North Carolina — the Outer Banks — police have set up a checkpoint to turn back anyone, even a second-home owner, who’s not a full-time resident. The tiny island of North Haven, Maine, has banned all visitors, including people who own property, while locals in Vinalhaven tried to forcibly quarantine three people by downing a tree across their street because their car had out-of-state plates. In Marfa, Texas, like dozens of other vacation spots across the country, the local government has requested that all short-term rentals be shut down. But locals I spoke to in Marfa and in towns across the West suspect that people are still renting under the table, or have simply transformed their Airbnbs into three-to-four-month furnished rentals and are listing them on Zillow, Craigslist, and Facebook Community Pages instead.

In Montana, where I live, state residents have been officially advised to shelter in place, but short-term rentals have not yet been restricted. Vacation rental revenue estimates for early March in the Whitefish zip code rose from $1.1 million to $2.1 million, year over year. And a Whitefish rental company recently sent an email blast advertising the area’s “low population to help with social distancing” for those “looking for a great spot to isolate or self-quarantine.” (After community outcry, the owner apologized.) A luxury travel booker told Forbes she’s still busy booking “a lot of resorts in mountain areas,” including Paws Up Resort, 45 minutes outside of Missoula, which bills itself as “like a national park, but private.” Cabin rentals currently start at $1,250 a day. The owners of one Airbnb in Bozeman briefly listed it as “The Last Best Place to Quarantine.”

More than two dozen residents of various rural areas — most of whom did not want to give their full name or exact location for fear of losing tourist dollars — told me that the influx of newcomers seems to have slowed over the past week. Local governments began issuing proclamations to shutter short-term rentals — and publicly requested that visitors stay away. But thousands of people have already arrived with plans to stick around for months, and the vast majority of communities can’t or won’t turn back people who already own property in the area. They can advise them to self-quarantine for 14 days, but they can’t enforce it.

“The relationship between full-time residents and part-timers is already at a breaking point,” Jean Hardy, who’s currently finishing his doctoral degree in rural technology and economic development at the University of Michigan, told me. “There is an intense wealth gap that’s only going to be reinforced and exacerbated. And the perceived urban/rural divide is only going to get worse in that the continued reliance on rural areas as a place of respite is only going to get worse.”

Second-home and rental property owners pay property taxes, and in many of these towns their presence has become crucial to the area’s economy, which has transitioned from resource extraction (fishing, logging, mining) to recreation and tourism. Yet these towns have not been designed to support massive influxes of off-season residents. They don’t have the sanitation capabilities. In springtime, their supply chains, which keep the small number of grocery stores stocked with food, aren’t ramped up for peak winter or summer populations. Their broadband can’t support the demands of hundreds or thousands of cooped-up new residents, eager to stream Netflix the same way they did in more urban areas.

Most people arriving from cities aren’t thinking about these things — and that, full-time residents of these areas say, is part of the point. They don’t know the fine balance of these communities, because most of these new arrivals, even those with second homes, don’t really know these communities at all. They don’t know the state of the school systems, the size of the hospitals, the limitations of the supply chain for food, or how the spread of short-term rentals has exacerbated affordable housing crises because those things — save in the case of an emergency — just don’t affect them.

“The worst part is that these second-home owners are coming up and acting like isolation is a vacation,” said Jen, 39, who lives in the northwest Colorado Rockies.

That sense of entitlement is nothing new in the US. “Rural, nature-heavy environments have long served as a way for a privileged (and overwhelmingly white) ‘Us’ to get away from an othered and less-privileged ‘Them,’” writer Rahawa Haile pointed out last week on Twitter. “People of means who feel entitled to space and perceived ‘purity’ will flock to it if law and infrastructure allow it.” Ashleigh Weeden, who’s completing her PhD in rural studies at the University of Guelph, told me that many people still think of rural and remote places as “empty,” as places of escape — which, in her words, “ignores that there are entire communities of people who live there year-round and indigenous people who’ve lived in these places since time immemorial.”

> “The worst part is that these second-home owners are coming up and acting like isolation is a vacation.” 

That view also helps explain some of the behaviors that full-time residents have reported seeing among the influx of out-of-towners. “They’re not respecting the locals who are desperately trying to maintain guidelines when grocery shopping or getting out for exercise. They’re strolling the aisles in outdoor gear, casually grabbing something for supper that night — not isolating and disinfecting like the locals are,” Jen said. “We know how precarious our situation is. The level of disrespect is palpable. And it hurts to think of what could be on the horizon due to their careless and self-entitled actions.”

In Jen’s hometown, the local medical community is using social media to plead with people who don’t live in their community full time to stay away. After all, even if most people who flee the city carefully self-isolate and don’t spread the virus, there will doubtless be some who do. And knowingly or not, they will spread it to those who don’t have the luxury of fleeing to a vacation home: the essential workers in the small local hospital, the clerks at the grocery stores, the people delivering takeout.

Some city dwellers with second homes might object to being painted with the same brush as people renting a house in the countryside on a pandemic-inspired whim, feeling that they are also part of a rural community — and in some cases that they’re being more careful than the people who live there. Jessica, 39, grew up in the upper Hudson Valley and currently owns a home in the lower Hudson Valley, along with an apartment in Brooklyn. She says she spends slightly more of her time upstate, pays taxes there (including income taxes), and supports local businesses. She votes in local elections. And she finds the vitriol directed specifically at second-home owners upsetting.

“I’ve been in my house (with short, concise store runs only) for 10 days,” she told me. “My local neighbors, on the other hand, are proceeding as usual. The teen next door is regularly coming and going, drinking beers with friends and generally hanging out despite bars and restaurants being closed. If there is spread in this small town, it will be due to their behavior, not mine.”

She admitted that all her reasoning “goes directly out the window” if she believed she had been exposed to the virus. “But if I’m healthy, and I paid for a space that is bigger, more comfortable, and more conducive to long-term lockdown, I’m using it,” she said. “If you have an economy reliant on second-home owners, then you have to allow people to access their property.”

Most second-home owners — in the Hudson Valley or elsewhere — aren’t like Jessica. They pay property taxes but not income taxes. They don’t vote in local elections. They have very little sense of the issues facing a community unless they’re directly affected by them (see: septic systems). Nish, 37, lives in a part of central Idaho with two ski resorts that rely on second-home owners and short-term renters from Boise and North Idaho. The resorts are now closed, and the restaurants in her area voluntarily went to takeout only. But the area is still “at the mercy,” as she puts it, of statewide policies — which, even with clear evidence of community spread in Blaine County and Boise on March 18, did not institute a statewide stay-at-home order until March 25.

“We’re not able to temporarily prohibit short-term rentals because of state law, so there are still nearly 500 homes available to rent to folks looking to flee the cities and ride out the virus elsewhere,” Nish told me. “Our grocery shelves are thin — but it takes us longer to get restocked because we’re rural. And local full-time residents are taking this incredibly seriously. Most families are isolating at home, effectively volunteering to shelter in place in order to protect our town from spreading the virus if it arrives.”

In Nish’s community, the hospital has recently attempted to modernize, but there are only 15 beds total. Three ER beds. One ventilator. “We’re worried about our health care providers,” she said. “The nurses and physicians and other health care workers are our friends, our neighbors, our spouses. They are known and beloved in our community. If 0.5% of our full-time resident population gets sick, we are out of beds,” she said. “Any influx of additional residents would decimate our system in an instant if we had even a small influx of COVID-19 cases. The next closest hospital is in Grangeville, and their hospital beds are the same as ours.”

This past weekend, two cars showed up on the street with Boise plates. The owner of one said they’ll be there for the foreseeable future. The other reported they’ll be “back and forth.”

“It’s a hard and scary time to be in the city; we certainly understand that,” Nish continued. “The threat of community spread of COVID-19 is immense in densely populated areas, and of course we are worried for our friends and families who live there. But it’s a scary time in rural places, too. If the virus comes here, our options are drastically limited. It could overtake our town and areas like ours in a matter of days.”

In a recent article on class and the coronavirus, the New York Times described the development of a “kind of pandemic caste system” with “the rich holed up in vacation properties; the middle class marooned at home with restless children; the working class on the front lines of the economy, stretched to the limit by the demands of work and parenting, if there is even work to be had.” Most of these resort towns have little in terms of a traditional middle class: There are the people the town caters to, and then there are the people doing the catering. Many of the people who provide essential services, from teachers to servers, are forced to live miles outside of the town they serve. There are massive shortages of affordable housing; livelihoods already hinge on a good snow season or the increasingly risky bet that the area won’t be affected by wildfires or flooding.

And some of these places — particularly in northern states like Michigan, Montana, and Idaho, with abundant natural sources of water — have already been identified as places to retreat from the effects of climate change. “Rural communities are going to see an uptick, outside of the coronavirus, of people buying property and second homes as a refuge from climate change,” said Hardy, whose research focuses on Michigan’s Upper Peninsula. “And it’s the same thing with the so-called coronavirus refugee: People are thinking, Where do we want to be in a disaster situation? Where is the most safe? And the answer, to them, are these rural places.”


Rural studies scholars debate constantly about what qualifies a place as rural — is it the number of people who live there? The density? The feel? An influx of people, hungry for the same conveniences they have in their urban life, not only changes the feel of a place, but also displaces the people who made that town what it was in the first place. It’s not just the projected medical shortages, then, that scare rural residents. It’s the way these current migration patterns serve as a forecast for the future to come — one characterized, in Hardy’s words, by a sort of “disaster gentrification.”

>“People are thinking, Where do we want to be in a disaster situation? Where is the most safe? And the answer, to them, are these rural places.”

Those scholars also debate the different categories of rural: the places that have fully embraced the amenity-rich tourism-dependent strategy (Whitefish, Aspen, Hudson Valley), the places transitioning to that model from land-based economies, and the places, in Hardy’s words, that are poor, struggling, and have no real path toward a tourist economy (areas of the Mississippi Delta and Appalachia, as well as hundreds of former ranching, farming, or mining communities across the US). Right now, much of the national media’s focus is on areas in those first two categories. But COVID-19 is undoubtedly coming for the poor rural areas, too.

It will take longer, and it might not solely be through rich visitors. Instead, it will spread through retirement homes, as it has in Lander, Wyoming, and decimate the disproportionately elderly populations that fill these rural states. It will spread through Native American reservations, where the Indian Health Service is unequipped to deal with the crisis, and where many extended families live together in one home. It will be particularly dire in the rural South, where community members are more likely to be uninsured and living in poverty than anywhere else in the county. It will come home with truck drivers and gas station attendants and those who work or shop at Walmarts in the closest midsize town. It will come to the dozens of counties whose hospitals have closed as their governors continue to refuse Medicaid expansion. On March 30, nearly half of the nation's rural counties had reported at least one confirmed case of COVID-19.

The virus, some people have taken to saying, “does not discriminate.” But that’s not quite true. It is putting our class and racial hierarchies in harsh relief — systems that favor the rich and the globally mobile while declaring the work of so many of the working class “essential.” Wealth is the vector. And the economically precarious will suffer because of it — whether they’re cleaning the offices of the infected in New York or checking groceries in Blaine County, Idaho.

“People think in their hearts that they’re doing the right thing,” Ashleigh Weeden, one of the rural studies scholars, said, “that they’re going to be isolated in these places and far apart — and that they might be bringing some economic development on top of it. I don’t think they’re malicious. I just think it’s a bit clueless.”

And that’s the thing about all of this: No one, except maybe this guy, thinks they’re being an asshole. They think they’re doing the right thing, for them and their family, in the moment. Some people fleeing the city were stuck in small apartments (although many, if they have second homes, are probably stuck in pretty large apartments). We all have natural flight responses when danger settles in our area.

I spoke with a woman who had a baby a week ago and spent several nights in a sleepless haze debating whether it was ethical to go stay with her mom in Maine. Their plan was to isolate for 14 days, but what if they brought the virus with them? I know dozens of others who aren’t rich but are desperate to get away, to get home, to get somewhere where their safety feels more under control. Some are camping in their parents’ backyards for two weeks before reintegrating. Some are students who would otherwise be stuck in group housing. Some have lost their jobs, and already need a way to start saving on rent. And some, like the woman going to Maine with her newborn baby, are just desperate for help.

When I asked Weeden about situations like this, she was deeply sympathetic. “It’s so complicated,” she said. “It’s so very human. We live a physical existence, and we have connections to physical places,” whether we’ve spent our childhoods going there, or just associate them with care and safety. Not everyone feels that way about their home, but many do. Weeden thinks that if someone arriving from a city to stay with family does isolate and turns out to be asymptomatic, they might be able to provide the sort of in-home care for other family members who could otherwise be forced to rely on health care workers. Going home — safely, even to rural communities — isn’t universally the worst decision.

The question to ask, then, is whether your relocation to a rural place will be a net help or a harm — not for you, personally, but for the community itself. Americans struggle mightily with the ideology of individualism: that all that matters, in a particular moment, is what is happening to you and yours. Rural America is asking you to think otherwise. You might “enjoy” your quarantine more. But the rural places so many Americans treat as playgrounds, and the workers who make that play and respite and feeling of safety possible, may suffer profoundly in your service. ●