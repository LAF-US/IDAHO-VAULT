---
outlet:
- Idaho State Journal
url: https://www.idahostatejournal.com/freeaccess/opinion-beware-of-reading-time-with-the-queens/article_0366ad88-b921-11ed-ab33-7f01a65b72a3.html
author:
- Mike Ewing
related:
- AMI
- Christopher Rufo
- Europe
- Idaho
- Idaho State Journal
- Michelle
- Pocatello
- San Francisco
- Southeast Idaho
- Thomas
- 'Yes'
- YouTube
- books
- children
- definition
- drag
- end goal
- pair
- religion
- teachers
authority: LOGAN
---
If you wonder who thinks it’s a good idea for adult drag queens to perform for young children, 3 to 8 years old, you might want to read an article titled, “In the War to Destroy Society, Drag Queens are the Shock Troops” by Paula Rinehart, The Federalist, Jan. 23, 2023. Rinehart draws heavily from an article titled “The Real Story Behind Drag Queen Story Hour” by Christopher Rufo, City-Journal, October 2022. Both articles include additional references to writings of authors — mostly university professors, list attached below. Here’s some background.

In 1984, after years of immersion in the gay world of San Francisco, in parallel with academic study leading to a Ph.D., Gayle Rubin wrote “Thinking Sex, Notes For a Radical Theory of the Politics of Sexuality.” Among many points, Gayle Rubin argued that a sexual hierarchy, a pyramid, exists in the western world — i.e. the U.S. and Western Europe. Rubin says this hierarchy is artificially constructed, and it is heavily influenced by Christian religion. The pinnacle of her hierarchy is occupied by married, reproductive, monogamous, heterosexual couples. Stable long-term gay or lesbian couples are found at a mid-level. The base of the pyramid is filled by transsexuals, transvestites, fetishists, sadomasochists, sex workers, porn models and pedophiles. Practitioners in the lowest level are persecuted by the legal system, says Rubin. She argued that all forms of consensual sex are natural in various locations of the world and they should be acknowledged with equal respect. Rubin further argued that the world could be made a better place by toppling the existing pyramid; that is, by eliminating the binary married norm at the top of the pyramid, normalizing the behaviors on the base of the pyramid and eradicating religion from society. A few years later, Rubin walked back to some degree the idea of accepting adult-child sex, one of the bottom-row activities.

In 1990, Judith Butler published a book called “Gender Trouble: Feminism and the Subversion of Identity.” Judith Butler argued that gender is artificially constructed, similar to Rubin’s sexual hierarchy, and it is manifestly unfair to women. Yes, biological women can be identified by physical characteristics; however, womanhood, distinct from biology, is a set of behaviors that are passed down from generation to generation. These thoughts are embedded in the definition of Third Wave Feminism that came onto the American scene after the Supreme Court confirmation fight of Clarence Thomas. Like the thinking of Rubin, Butler argued that the world would be a better place if the binary set of gender definitions, male and female, is tossed out, to be replaced by a larger and ever-changing list of gender variations. And, nix the religious influences. A lengthy interview in May, 2022, confirms that Butler continues to hold the same views.

Notice in the previous two paragraphs that two separate culture-changing efforts are rolling simultaneously. One effort follows Rubin and espouses that many permutations of sexual practices exist. This effort has an end goal of every sexual practice or desire being equally accepted. The other effort, Butler-esq, focuses on genders to the point where a single definition of female has been replaced by dozens of genders. The main purpose of Butler’s thinking is to create a world where women absolutely control their own gender descriptions, bodies and lives. In a 2023 world, having more than 100 genders on some ever-expanding lists, it has become impossible for anyone in the enemy group to not fall into a trap. Think how easy it has become in the U.S. to lose a job by not adequately respecting someone’s adopted and artificially constructed pronouns. This is by design.

In 2015, Michelle Tea created an organization called Drag Queen Story Hour (DQSH) in San Francisco. At this moment approximately 40 chapters of DQSH exist in the U.S. Rufo’s essay states that Michelle Tea founded DQSH as a way to expose her young child to queer culture.

Over the last two or three decades, outward expressions of Gay Pride culture expanded tremendously in the U.S. and Western Europe. With this expansion, a problem developed: Some of the more aggressively edgy participants in the Pride culture, through public displays, were jeopardizing good will that had accumulated in the era of stable same-sex couples. Some of these edgy groups are examples from the Gayle Rubin hierarchy. Possibly to soften alarming effects of some of the edgy public displays, in 2020, Harper Keenan and Harris Kornstein authored an academic paper called, “Drag Pedagogy: The Playful Practice of Queer Imagination in Early Childhood.” Keenan is a professor in the Department of Curriculum and Pedagogy at the University of British Columbia. In other words, Professor Harper Keenan creates teaching techniques and programs that are adopted by other teaching professionals. Kornstein performs in drag using a stage name Lil Miss Hot Mess and now is a university professor.

Together, Kornstein and Keenum developed a method of teaching ideas to young children using drag queens as teachers. The concept is that drag queen teachers who are charismatic, enthusiastic, happy, loud, brightly dressed, welcoming, perhaps musical and good story tellers can be successful at planting a variety of ideas in the minds of children. One objective of this teaching method seems to target children for new ideas without stirring up skeptical adults.

Turning to drag queen library performances in Pocatello, Idaho, it is important to clearly state that no evidence is visible to indicate that the local Reading Time With the Queens troupe (RTWTQ) is pushing an agenda in line with the anything-goes ideas of Gayle Rubin. Most of the children in attendance are 3 to 8 years old, approximately; and, books featured in library events are targeted for the 3 to 8 age group, according to recommendations from internet book merchants. Most of the presented books are familiar children’s books, Mr. Rogers and Dr. Seuss are examples. Some books presented by the queens are definitely LGBT inspired. Two Grooms on a Cake is an example. Based on the stories and songs in a typical performance, and especially from the interspersed comments from the drag performers, it is easy to infer that seeds are being planted. A pair of subtle undertones are identifiable. The first seems intended to motivate children to explore a variety of gender identities, or to at least be part of an accepting and affirming peer group for other children who decide to explore. A second undertone suggests to children that a non-traditional “family,” a queer family, is ever-present that is easy to join, and this non-traditional family is a superior replacement for a traditional family.

Getting closer to a possible answer as to who might think drag library performances are a good idea: Harris Kornstein, a.k.a. Lil Miss Hot Mess, published in May, 2020, a children’s book called, “The Hips on the Drag Queen Go Swish, Swish, Swish.” The Pocatello troupe, Reading Time With the Queens performed a singing version of “The Hips on the Drag Queen go Swish, Swish, Swish” as part of a February 2022 library performance. The video is available on YouTube. This might make a person wonder if the Pocatello RTWTQ troupe has purposely implemented the “Playful Practice of Queer Imagination” teaching strategy invented by Keenan and Kornstein. Further, the subliminal messages in the Pocatello drag queen library performances seem to line up with Judith Butler’s Third Wave Feminist ideology. This might partially explain why the majority of adults accompanying children to Pocatello drag queen library events are younger women. It is interesting to note that some young mothers bring children to a once-a-month library event to have a drag queen read two books to the children that the mother could easily have read at home.

Authors cited above: Gayle Rubin, professor, U Michigan; Judith Butler, Professor, U Cal, Berkeley; Michelle Tea, founder of Drag Queen Story Hour. All of these authors are influential in the feminist movement. Additional authors: Harris Kornstein, Professor, U Arizona; and Harper Keenan, Professor, U British Columbia; Paula Rinehart, The Federalist, Jan. 23, 2023; Christopher Rufo, City-Journal, October 2022.

**Mike Ewing** came to Southeast Idaho in 1979 to work at American Microsystems Inc. (AMI) and he stayed because of the many recreational and personal opportunities.