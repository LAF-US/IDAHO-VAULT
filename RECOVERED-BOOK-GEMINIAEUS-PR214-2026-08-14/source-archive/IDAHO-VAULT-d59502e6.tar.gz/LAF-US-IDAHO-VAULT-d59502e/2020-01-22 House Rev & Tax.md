---
cmte: House Revenue and Taxation
related:
- '120'
- '124'
- '135'
- BPA
- Collins
- DFM
- Gary Collins
- House Revenue and Taxation
- Idaho
- LSO
- Scott Bedke
- Tax Relief Fund
- budget
- dollars
- grocery tax
- online sales tax
- property tax
- property tax budget
- sales tax
- seniors
- taxes
authority: LOGAN
---
House Revenue and Taxation

Ch. Gary Collins 

RS: grocery tax Credit – Speaker Scott Bedke

Raise grocery tax credit from $100 for non-seniors to $135, seniors $120 to $135 also

Would negate effect of sales tax on food, DFM says average Idahoan spends $124 on food tax per year

Mentality in the past was: only limited funds, decide to bump up the amount for seniors and come back for the rest later. Policy decision by this committee before.

Lawmakers have analysis from LSO BPA, Married couple w/ 1 child in legislator packet?

This cancels the effects of sales tax on food for nearly all Idaho citizens.

“For 99% of Idaho residents, this negates the effects of sales tax on food while keeping non-residents paying.” This change would cost between $48-49 million out of Tax Relief Fund from online sales tax, 6-7 million dollars per month.

RS: Moyle – property tax budget freeze

RS: Moyle – property tax budget cap

RS: Harris – Foregone Balance

The House Revenue & Taxation committee is gearing up for tax proposals this session. The hearing Wednesday saw the introduction of several bills aimed at reforming property and grocery taxes.