---
author:
- Ruth Brown
outlet:
- Idaho Reports
related:
- County Clerk
- Idaho
- Idaho Capital Sun
- Idaho Reports
- Jack Nelsen
- Jerome
- Jerome County
- Legislative District 26
- Ruth Brown
- Secretary of State
- election
- numbers
authority: LOGAN
---
_By Ruth Brown, Idaho Reports_

Jerome County reported an error on Thursday in vote count reporting, changing the result of the winner reported online for Legislative District 26 House Seat B in the House of Representatives. 

The new results show that Republican Jack Nelsen beat Democrat Karma Metzler Fitzgerald by 83 votes.

A press release from Jerome County said the publicly released numbers did not match the count. “As a part of the normal verification process that leads to the county election canvass, Jerome County elections staff encountered a series of discrepancies between the cast ballot counts printed on the reports produced by our central tabulator and those same counts subsequently released to the public as the “unofficial final results” on election night,” the press release stated.

The Jerome County Clerk’s news release said the discrepancy was unintentional.

“The ultimate cause of the issue was determined to be a missing “vote type” configuration in the translation process between the tabulated results and the publishing of those results to the state’s Election Night portal.  The absence of the vote type in this internal process resulted in a portion of the cast ballots not being attributed to the published online totals.  It is important to understand that the original totals printed by the tabulation equipment were accurate, remain unchanged, and allowed for the correct reconciliation with poll book records and voter counts as calculated on the evening of November 8th.”

House Seat B is the only race that was close enough to change the winner reported. 

“Our office reached out to those candidates impacted this morning, and while we regret the error, this office and the Secretary of State wish to emphasize that all results, as published on election night, are unofficial until certified by each county’s respective canvass and certified by the state canvassing board,” according to Jerome County’s news release.

The Idaho Capital Sun first reported this story.