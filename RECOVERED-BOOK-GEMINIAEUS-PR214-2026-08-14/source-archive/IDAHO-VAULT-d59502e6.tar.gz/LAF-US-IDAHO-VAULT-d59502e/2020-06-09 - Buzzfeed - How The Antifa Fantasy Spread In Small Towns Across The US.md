---
author:
- Anne Helen Petersen
outlet:
- Buzzfeed News
URL: https://www.buzzfeednews.com/article/annehelenpetersen/antifa-rumors-george-floyd-protests
related:
- '500'
- '800'
- Anne Helen Petersen
- Antifa
- County Sheriff
- Donald Trump
- FBI
- Facebook
- III
- Idaho
- Lewiston
- Liberty
- Missoula
- Montana
- New York
- North Idaho
- Oregon
- Payette
- President
- Reddit
- Sandpoint
- Seattle
- Second Amendment
- Snake River
- Spokane
- Twitter
- Washington
- arrests
- cities
- election
- emoji
- law enforcement
- neo-Nazi
- police
- racism
- religion
- sign
- social media
- website
- white nationalist
- word
authority: LOGAN
---
*Rumors of roving bands of Antifa have followed small protests all over the United States. Why are people so ready to believe them?*

The rumor that shadowy leftists planned to start trouble in Great Falls, Montana, first appeared on the Facebook group of the Montana Liberty Coalition late last Wednesday afternoon.

“Heads up,” a man named Wayne Ebersole, who owns a local cover crop business, wrote. “Rumor has it that Antifa has scheduled a protest in Great Falls Friday evening at 5 p.m. in front of the Civic Center.” He asked the group if anyone had any more information, or if anyone was available to “protect businesses.”

“It has been confirmed through the police department,” one commenter replied. “They have a permit for tomorrow night and are in town now.”

They weren’t. Police later said they had been “working to quell the rumor.” But that didn’t stop it from sweeping across various right-wing groups. Within 24 hours, a screenshot of Ebersole’s post had been posted to the Facebook Group for the Montana Militia, whose members have recently dedicated themselves to tracking the perceived threat of antifa all over the state, including coordinating armed responses to “protect” their towns. (Ebersole did not respond to a request for comment.)

And by Friday at 5 p.m., as about 500 protesters gathered to protest systemic racism and police brutality, a handful of armed men had massed at the edge of the demonstration.“We heard that a little group called Antifa wanted to show up and not in our town,” one man, who declined to be named, told the Great Falls Tribune. “All it takes is a word and a whisper.”

As protests against police brutality and in support of Black Lives Matter continue to proliferate across the small towns and rural communities, so, too, have rumors of white vans of masked antifa driving from town to town, reportedly intent on destruction. In Hood River, Oregon, antifa were, according to screenshot of a fake Instagram story, calling on followers to “root loot do anything in your power.” In Spring Hill, Tennessee, there was a “busload” staying at the Holiday Inn, prepping to loot Walgreens at noon. In Wenatchee, Washington, bands of men dressed in black were surveilling potential targets. In Payette, Idaho, a plane full of protesters was circling overhead. In Honolulu, antifa had been flown in from the mainland. In Billings, Montana, some claimed agitators had been spotted by the National Guard. In Nebraska, they were creating Craigslist ads offering to pay people $25 a day to “cause as much chaos and destruction as possible.” In Sisters, Oregon, they were planning to show up at the local Bi-Mart.

To be clear: All of these rumors were false. They were all, as the Deschutes County Sheriff’s Office put it, “fourth-hand information.” To combat them, police departments in dozens of towns are holding press conferences, posting announcements on social media, and telling anyone who calls the station that there has been no indication of a planned presence from antifa or any other outside agitators, whether “from Chicago” (code, in many parts of the Midwest, for black people) or “from Seattle” (code for liberals).

Yet these rumors continue to spread. That spread is facilitated by Facebook — where they thrive in groups whose previous focus was protesting pandemic-related shutdowns and circulating conspiracy theories about COVID-19 — and fanned by President Donald Trump, who recently declared his intention to label antifa a terrorist group. This morning, the president raised the antifa menace yet again, tweeting that the protester violently shoved by police in Buffalo, New York, “could be an ANTIFA.” (He was not.)

But the persistence of these rumors suggests a deeper fear of outside incursion, and the necessity of an ever-alert, armed response. As encapsulated in a Reddit thread out of Hood River, Oregon: “I’ll say this much: The people out here are armed to the teeth. If you want to bring mayhem to this area, the end result will likely have you begging for police protection.”

Antifa has become the right’s face of violent leftist protest in the United States, sloppily aligned with, as the president put it on June 1, “professional anarchists, violent mobs, arsonists, looters, criminals, rioters.” In a tweet, Trump claimed the national guard had “shut down” the “ANTIFA led anarchists, among others.” (The DC field office of the FBI reported no antifa involvement in protests, according to the Nation.)

It’s difficult to talk about antifa with any sort of precision. It’s “leftist” insomuch as it’s against, well, fascism, authoritarianism, and white supremacists. There are some local groups, but there’s no national leadership structure. Many antifa dedicate themselves to finding white supremacists in their communities and outing them. Most people within those groups are for violent protest only as a last resort, but a handful are for more forceful displays and destruction. Here in Montana, I encountered a very small handful in January 2017, when they showed up in Whitefish to counter a planned march by the Daily Stormer, a neo-Nazi website.

The most important thing to understand about antifa is that there are very, very few of them: According to the Washington Post, when the group tried to gather nationally, they topped out at a few hundred.

Nevertheless, Trump has been building up the menace of antifa for years. He first began evoking antifa following the Charlottesville “Unite the Right” rally, when he famously claimed that there were “very good people, on both sides.” “Since then Trump has returned to the term often in speeches,” Ben Zimmer writes in the Atlantic, always “with an air of alien menace.”

Lifted by Trump’s rhetoric, that “alien menace” has accumulated around antifa in the public imagination, making it all the easier to believe posts in which fake antifa accounts promise to act in the exact ways Trump has described. On Sunday, May 31, a newly made Twitter account — since linked to the white nationalist group Identity Evorpa — posted: “Tonight’s the night, Comrades,” with a brown raised-fist emoji and “Tonight we say 'F--- The City' and we move into the residential areas... the white hoods.... and we take what's ours …”

The antifa threat has also been co-opted by QAnon, the nation’s most powerful and influential conspiracy theory and movement. At Concordia University, Marc-André Argentino researches the way extremist groups use social media as a tool to recruit, spread propaganda, and incite acts of violence. Last week, he began tracking the uptick in mentions of antifa within QAnon social media forums, which began to rise when “Q” (the anonymous poster who guides the site) began mentioning it on May 30. At least for the moment, QAnon is celebrating the protests (and antifa’s presence) for their potential to spark the apocalyptic “storm” central to the QAnon theology. “Antifa is a nebulous enemy, one that serves as a rallying cry for keyboard warriors and on-the-ground militiamen,” Argentino told me.

Argentino has been noticing something else, too: a growing cross-pollination between QAnon, which is often referred to simply as a conspiracy group, and more far-right extremist groups, from the so-called Boogaloo Bois and Proud Boys to more straightforward militias.

This intermingling was on display at the Reopen Michigan protests, where American flags waved alongside Confederate ones. And you can see it now all over the West, where the groups that advocated for reopening — often attracting a motley mix of constitutionalists, “patriots,” anti-vaxxers, Second Amendment advocates, anti-government advocates, and just straight up pissed off business people — have shifted their focus to “protection.” In the Tri-Cities area of Central Washington, the shift is so explicit that the Facebook group “Reopen Tri-Cities” has shifted, wholescale, to a second group called “Protect the Tri.”

In Montana, most of the rumors of antifa presence in the state can be traced back to state Sen. Jennifer Fielder, who warned her followers on June 1 of “multiple reports from credible witnesses” that five white panel vans of antifa were on their way to Coeur d’Alene, Idaho, and would then proceed to Missoula, Montana. Fielder, who lives in Northwest Montana, is known across the state for ultra-right, “liberty-minded” views on everything from public lands (they should be sold) to contact tracing (a form of governmental overreach).

But Fielder didn’t start the antifa rumor. She just brought it to Montana. On Sunday, June 1, over in Klamath Falls, Oregon, the rumors were so compelling that hundreds of armed people showed up to line the Main Street during a planned protest. The next night, in downtown Coeur d’Alene, Idaho, a man with an AR-12, an AR-15, two 9 mm handguns, and a .38 special told reporter Bill Buley that he was there, along with hundreds of others, because he’d heard “there were some people who shouldn’t be here.”

In some cases, the people with guns showing up at these rallies are “supportive” of the groups protesting — at least in so far as they’re supportive of the right to freely assemble. They don’t actually believe the protesters, in many cases local high school students, would turn to violence. Instead, they believe antifa is plotting to infiltrate the otherwise peaceful protests and turn them violent — or, as was suspected in Lewiston, Idaho, use the protest as a decoy in order to ransack the business district.

Which is why, as over a thousand people gathered to march along the Snake River in Lewiston, dozens of others, many heavily armed, lined the streets downtown. One wore a Hawaiian shirt (the “uniform” of the Boogaloo Bois) and held a sign with the name of a III% militia member who had been shot by the police. Another wore a vest covered in Nazi paraphernalia. Others were decked out in flak jackets, in camo, and Clinton Conspiracy shirts. Similar scenes have played out this week in Bozeman, Kalispell, Billings, Sandpoint, and Coeur d’Alene.

Travis McAdam, who’s tracked anti-government and hate groups for 15 years with the Montana Human Rights Network, calls it the “Antifa Fantasy.” A version of this fantasy has long existed, in some form, in militia circles: “An outside, shadowy entity is going to come in,” McAdam recounted, “and whether it’s to disarm the community or attack it, these folks are going to mobilize and fight it off. Antifa is just the bogeyman that they’ve stuck in this narrative.”

Put differently: Militia members get to plan, anticipate, and enact the idea at the foundation of their existence. And they get to do it in a way that positions them as “the good guys,” fighting a cowardly bogeyman easily vanquished by show of force alone. As a popular meme circulating in North Idaho put it, “Remember that time when Antifa said they were coming to Coeur d’Alene / And everyone grabbed their guns and they didn’t come? That was awesome!” It doesn’t matter if antifa was never coming in the first place. They didn’t come, and that’s evidence of victory.

And that victory can then be leveraged into further action — and a means to extend the fantasy. On the Montana Militia page, a man named Tom Allen, whose home is listed on Facebook as Wibaux, Montana, posted that he’d spent the night in Dickenson, North Dakota, “protecting” the veterans monument during a planned protest. A group of bikers showed up to guard the nearby mall, protecting “all of Antifa’s usual targets.” There was no incident. (Allen did not respond to request for comment.)

Afterward, Allen wrote, a man who had helped coordinate the defense followed a group of perceived antifa to an Applebee’s, where he said he overheard them talking about “the waitress and how they wanted to rape her,” “killing cops” and “other violence,” and their future plans: “They’re saying there’s going to be a ‘firestorm’ in Billings this weekend.” The post was shared more than 1,800 times.

Like Argentino, the online researcher, McAdam sees this current “protect” movement as an extension and consolidation of anti-government movements that have been percolating for years. Back in 2008, when tea party rallies began sprouting up all over the United States, many of them were attended and organized by people authentically upset about economic policies. But those protests, like the reopen protests, also drew in anti-government agitators and militia members, who then began to influence and, in some cases, take over the leadership in the tea party groups.

“That dynamic is very similar to what’s happening now,” McAdam said. “A core group of people coming from the anti-government movement are always looking for a crisis, where you have a divisive issue in the community that they can tap into and exploit. The COVID pandemic was one thing, and now we’ve got another avenue.” And people who might not ever consider themselves “militia” or even anti-government, who might have joined a reopen group in frustration, are now exposed, and perhaps more receptive, to rumors of roaming antifa in need of rebuke.

“You can really see that in the Facebook groups,” dozens of which McAdam monitors. “I would see people posting early on a Tuesday morning, saying, ‘I don’t know if this Antifa rumor is real,’ and then later in the day, they’d be like, ‘Well, I dunno if I believe this, but I’m going to go drive around Missoula and look for these Antifa vans.’”

When someone in your Facebook feed posts a warning to be on the lookout for antifa in your small town, it might seem like low-stakes nonsense. But beneath such a seemingly silly rumor lurks a larger ideological iceberg: the idea that radical leftists are out to defile and destroy, and the only recourse against them is an armed, unrestricted militia. QAnon theory builds on this, suggesting that all of it — the protests, the police reaction, the presence of antifa — has been preordained as part of a coming mass destruction

And QAnon isn’t just a niche conspiracy theory. Tweets from its proponents are regularly retweeted by the president. At least 50 current or former candidates for Congress, plus the Republican nominee for the US Senate in Oregon, are public QAnon supporters. And that doesn’t even include candidates running on the state or local level.

As Adrienne LaFrance argued in the Atlantic, QAnon has become a religion, with clearly defined sides of good and evil, hungry for converts. The antifa fantasy functions similarly. Whether you’re in Lewiston, Idaho, or Klamath Falls, Oregon, it’s so, so easy to believe.

And as QAnon continues to cross-pollinate ideas with violent, extremist groups, “keyboard warriors” may bring their conspiracies into the real world. As Argentino put it, “If you’re in QAnon, and you see your messianic leader, Trump, at risk of losing the election, and the mass arrests that Q has promised is not coming, at some point people are going to question: If the Q team and Q can’t do this themselves, maybe they need the digital patriots to become offline patriots.”

On June 2, Trump sent out a blast to his email list. The subject line: ANTIFA. “Dangerous MOBS of far-left groups are running through our streets and causing absolute mayhem,” the email said. “They are DESTROYING our cities and rioting — it’s absolute madness.”

That night, in Forks, Washington, a multiracial family from across the state in Spokane pulled up to a local outdoors store. They were in a decommissioned school bus and picking up supplies on their way to go camping. In the parking lot, a group of people from seven to eight cars surrounded them and accused them of being antifa. According to a statement from the sheriff’s office, the family then drove off to their camping site, trailed by a handful of cars. In two of the cars, people were holding semi-automatic weapons. As the family was setting up camp, they heard the sound of chainsaws and gunshots in the distance. When they attempted to leave, they found that trees had been felled onto the road, trapping them on site.

“For lots of folks, it’s much easier to accept the idea that the only people who could be protesting the local police would be from outside the area,” McAdam explained. “It couldn’t possibly be that people of color in our community could have bad experiences with local law enforcement.” Or, for that matter, with locals in general.

“The ‘outsiders’ part of this narrative is just so important,” McAdam said. “It allows people to say, and to believe: ‘We don’t have problems in our community.’” ●