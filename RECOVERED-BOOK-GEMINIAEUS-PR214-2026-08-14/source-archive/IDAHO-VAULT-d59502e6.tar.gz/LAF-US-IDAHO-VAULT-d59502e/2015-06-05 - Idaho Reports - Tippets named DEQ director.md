---
author: null
outlet:
- Idaho Reports
URL: https://blog.idahoreports.idahoptv.org/2015/06/15/tippets-named-deq-director/
related:
- Bennington
- Boise
- DEQ
- Department of Environmental Quality
- Idaho
- Idaho Legislature
- Idaho Public Television
- Idaho Reports
- John Tippets
authority: LOGAN
---
Sen. John Tippets, R-Bennington, has been appointed as the new director of the Idaho Department of Environmental Quality, as first reported by Idaho Reporter.

“I never planned on going to work for the state full time,” Tippets said in a Monday interview with Idaho Public Television. “I’m looking forward to it now.”

Tippets, who plans to move to Boise for the position, said he doesn’t plan on making major changes at DEQ.

“I told the governor that this wasn’t a department that needs someone to go in and fix it. It’s operating well. Director Fransen did a good job,” Tippets said.

That said, Tippets said he’ll miss serving in the Senate.

“Some of the best people I know serve in the Idaho Legislature,” Tippets said.

Tippets starts July 6.