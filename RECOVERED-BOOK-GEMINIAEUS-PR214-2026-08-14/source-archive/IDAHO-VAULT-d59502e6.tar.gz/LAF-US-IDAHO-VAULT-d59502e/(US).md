---
authority: LOGAN
related:
- HORIZON
- PROJECT
- UNIFIED
---

PROJECT HORIZON : UNIFIED SWARM 
