---
author:
- Alex Brown
outlet:
- States Newsroom
- Idaho Capital Sun
URL: https://idahocapitalsun.com/2023/06/16/half-the-nations-wetlands-just-lost-federal-protection-their-fate-is-up-to-states/
related:
- '118'
- Act
- Colorado
- Department of Environmental Quality
- Environmental Protection Agency
- Home
- Idaho
- Idaho Capital Sun
- Illinois
- Mexico
- North Carolina
- Paul
- Roberts
- Roy
- States Newsroom
- U.S. Supreme Court
- Virginia
- Washington
- agriculture
- books
- lakes
- legislative
- legislative session
- money
- rivers
- sign
- water
- wetlands
authority: LOGAN
---
## Supreme Court’s narrowing of the Clean Water Act has left some states scrambling to enact safeguards and others questioning whether regulators can handle workload 

States’ to-do lists just got a little longer: Decide how — or whether — to oversee building, planting and water quality in some wetland areas.

Last month, a U.S. Supreme Court decision struck down federal protections for wetlands covering tens of millions of acres across the country, leaving no regulation of those areas in nearly half the states.

The court’s narrowing of the Clean Water Act has left some states scrambling to enact their own safeguards and others questioning whether their regulators can handle the workload without their federal partners.

Other states, though, see the loss of federal oversight as an opportunity to roll back corresponding state laws at the behest of developers and farmers, who argue such regulations are overly burdensome.

“State protections are not all the same,” said Jim McElfish, senior research and policy adviser with the Environmental Law Institute. “It’s going to be up to the states to fill the gap, and they might act very quickly. It’s really going to be up to what the legislatures want to do.”

An analysis conducted by the institute found that 24 states have no state-level regulations for the wetlands that now lack federal oversight. Some, including Colorado, are looking to put such protections on the books.

Seven states, the analysis found, provide limited coverage of those waters, although lawmakers in North Carolina are seeking to block state regulators from taking control.

And in the 19 states with broad wetlands protections, environmental regulators worry that they don’t have the capacity to uphold state laws without the federal partnerships that had been crucial to permitting and environmental analyses.

### ‘States are going to need to step up’ after Supreme Court’s WOTUS decision
The court’s ruling found that the U.S. Environmental Protection Agency improperly claimed authority over an Idaho couple’s effort to build a house on their property. The decision limits the scope of wetlands covered by the Clean Water Act to those with a continuous surface connection to a larger body of water. It also cut protections for “ephemeral” streams that only flow seasonally.

More than half of the country’s 118 million acres of wetlands could be stripped from federal oversight, estimates Earthjustice, an environmental legal group. Advocates say the ruling ignores the fact that water often flows below ground, meaning unregulated wetlands could spread contamination to nearby lakes and rivers that the law does safeguard.

“Where the Supreme Court is tying the hands of the federal government to provide safe, clean water, the states are going to need to step up and act to fill the gap,” said Howard Learner, president and executive director of the Environmental Law & Policy Center, a legal advocacy organization in the Midwest.

In Colorado, state lawmakers and officials say they’re committed to restoring protections. State Sen. Dylan Roberts, a Democrat who chairs the Agriculture and Natural Resources Committee, said legislators will be analyzing the issue before next year’s legislative session. Meanwhile, regulators with the Colorado Department of Public Health & Environment have developed a draft policy to protect waters under state law.

“The fact that we have sources of water that are at risk of being contaminated or eliminated because of this Supreme Court decision should be concerning to all of us, and we should try to find the proper way to protect them,” Roberts said. “In the next couple months, we’ll know whether the state department can do this on their own or if they’re going to be making a legislative ask.”

Environmental advocates say they’re confident the state will ensure that wetlands and streams remain protected.

“We’re hopeful that we can restore protections here in Colorado,” said Ean Tafoya, Colorado state director with GreenLatinos, an environmental justice organization. “The state is considering a policy as a stopgap, and we’re likely to see legislation in 2024.”

In New Mexico, the state Environment Department already was pursuing its own surface water permitting program. John Rhoderick, director of the Water Protection Division, said it will take five to seven years to get the program up and running.

“This is going to give us the capability to better protect New Mexico,” he said. “We’re evaluating whether we need to somewhat modify our approach and do an interim rulemaking that addresses wetlands. But we’re on a good course and we’ll adjust as we see what the ripple effects from this ruling are.”

### Limiting state authority
Other states are attempting to roll back state water laws. North Carolina lawmakers passed a bill this month that would invalidate state wetland protections that go beyond federal regulations.

“The state law should be clear that state jurisdiction ends concurrent with the federal [standard],” said Ray Starling, president of the NC Chamber Legal Institute, the legal strategy arm of the business advocacy group. “The mentality and expectation of the General Assembly is that we don’t regulate more stringently than the federal government.”

Gov. Roy Cooper, a Democrat, has not indicated whether he will sign the bill.

> *Our waterways are only as clean as the wetlands that filter our pollution.
> – Kelly Moser, Southern Environmental Law Center*

Business, development and agriculture groups cheered the court ruling last month, arguing that confusing regulations and lengthy permit times were stifling economic growth. Now, they’re turning their efforts to the state level.

“We’re very happy with the decision, and we consider it a victory against federal overreach,” said Adam Pugh, environmental policy program manager with the National Association of Home Builders. “We do appreciate that a lot of states will continue to regulate and provide permits for those [waters]. We’re trying to make our state associations aware of any proposal that’s going to make homebuilding easier or more difficult and prepare them for that conversation.”

The group’s North Carolina chapter supported the bill to roll back state wetland protections. But environmental groups say that effort is misguided.

“Our waterways are only as clean as the wetlands that filter our pollution,” said Kelly Moser, senior attorney and leader of the Clean Water Program at the Southern Environmental Law Center. “This opens up millions of acres of wetlands to development and industrial pollution, wetlands that we have as a region relied on to protect our communities from increasing floods.”

Even in states with wetland laws, regulator capacity issues remain
Even in states with established wetland laws and permitting programs, the Supreme Court decision is shaking things up. State agencies work closely with federal regulators to conduct analysis, review proposals and process permits. But now, for those wetlands, states largely are on their own.

“We expect there are going to be delays [in issuing permits] if we maintain our current staffing level,” said Lauren Driscoll, manager of the wetlands program at the Washington State Department of Ecology. “To maintain the timelines that we have right now, we’re going to need to bring in additional people.”

The agency would need legislative approval to bring on more staff. Washington estimates that more than 50% of its wetlands have lost federal protection, and it will have to process roughly 50 additional applications each year for projects that no longer fall within federal jurisdiction.

Moser, with the Southern environmental law group, expressed concern that the Virginia Department of Environmental Quality also will struggle to handle the increased workload.

“Even though Virginia has wetland regulations on the books, they simply don’t have the expertise or resources to fill the gap,” she said.

The agency did not make officials available for an interview.

In Colorado and New Mexico, officials have acknowledged that efforts to enact state protections will require a lot more money in order to increase capacity at regulatory agencies. And in Illinois, advocates pushing for a wetlands law say it would be meaningless if state agencies weren’t able to handle the work.

“If you put in a state law that provides specific wetlands protection, that implies a permitting and review system, which is a significant capacity issue,” said Paul Botts, executive director of the Wetlands Initiative, a Chicago-based nonprofit. “There’s no point doing that if the agencies can’t carry it out.”