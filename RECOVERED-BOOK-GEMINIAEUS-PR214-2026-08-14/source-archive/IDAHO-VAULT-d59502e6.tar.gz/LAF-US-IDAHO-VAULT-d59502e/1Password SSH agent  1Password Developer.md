---
source: https://developer.1password.com/docs/ssh/agent/?utm_medium=organic&utm_source=oph&utm_campaign=windows
author: null
published: null
created: 2026-03-30
date created: Monday, March 30th 2026, 6:34:48 pm
date modified: Monday, March 30th 2026, 6:57:11 pm
related:
- 1Password
- '2026-03-30'
- RSA
- SSH
- agent
- meeting
authority: LOGAN
---
The 1Password SSH agent uses the SSH keys you have saved in 1Password to seamlessly integrate with your Git and SSH workflows. It authenticates your Git and SSH clients without those clients ever being able to read your private key.

In fact, your private key never even leaves the 1Password app. The SSH agent works with the SSH keys stored in 1Password, but never without your consent. Only SSH clients you explicitly authorize will be able to use your SSH keys until 1Password locks.

Learn how to [turn on the 1Password SSH agent](https://developer.1password.com/docs/ssh/get-started#step-3-turn-on-the-1password-ssh-agent) and [configure your SSH clients](https://developer.1password.com/docs/ssh/get-started#step-4-configure-your-ssh-or-git-client).

## Requirements

> [!-success] -success
> tip
> 
> For the best experience when using the 1Password SSH agent, you can configure [Touch ID](https://support.1password.com/touch-id-mac/), [Apple Watch](https://support.1password.com/apple-watch-mac/), [Windows Hello](https://support.1password.com/windows-hello/), or [system authentication](https://support.1password.com/system-authentication-linux/) to unlock 1Password and authenticate SSH key requests.

## Configuration

By default, the 1Password SSH agent will make every [eligible key](https://developer.1password.com/docs/ssh/agent#eligible-keys) in the built-in [Personal](https://support.1password.com/1password-glossary#personal-vault), [Private](https://support.1password.com/1password-glossary#private-vault), or [Employee](https://support.1password.com/1password-glossary#employee-vault) vault of your 1Password accounts available to offer to SSH servers. This configuration is automatically set up when you [turn on the SSH agent](https://developer.1password.com/docs/ssh/get-started#step-3-turn-on-the-1password-ssh-agent).

If you need to use the SSH agent with keys saved in shared or custom vaults, you can create and customize an [SSH agent config file](https://developer.1password.com/docs/ssh/agent/config/) (`~/.config/1Password/ssh/agent.toml`) to override the default agent configuration.

If you have more than six SSH keys available in the agent, you can edit your SSH config file or use [SSH Bookmarks](https://developer.1password.com/docs/ssh/bookmarks/) to match your keys to specific hosts. This will help you avoid authentication failures with OpenSSH servers that limit the number of connection attempts. Learn more about the [SSH server six-key limit](https://developer.1password.com/docs/ssh/agent/advanced#ssh-server-six-key-limit).

## Eligible keys

For the 1Password SSH agent to work with your SSH keys, your 1Password SSH key items must meet the following requirements. They must be:

- [Generated](https://developer.1password.com/docs/ssh/manage-keys#generate-an-ssh-key) or [imported](https://developer.1password.com/docs/ssh/manage-keys#import-an-ssh-key) using the `SSH Key` item type (which supports [`Ed25519` or `RSA`](https://developer.1password.com/docs/ssh/manage-keys#supported-ssh-key-types) key types).
- Stored in the vaults [the SSH agent is configured to use](https://developer.1password.com/docs/ssh/agent/?utm_medium=organic&utm_source=oph&utm_campaign=windows#configuration) in 1Password. By default, this is the [Personal](https://support.1password.com/1password-glossary#personal-vault), [Private](https://support.1password.com/1password-glossary#private-vault), or [Employee](https://support.1password.com/1password-glossary#employee-vault) vault of any 1Password account you're signed in to.
- Active items (not archived or deleted).

Any key meeting these requirements will automatically be available in the SSH agent for authentication. You will still be required to explicitly [authorize any request](https://developer.1password.com/docs/ssh/agent/security#authorization-model) an SSH client makes to use your keys.

To see a list of all keys that the agent has available, [set the `SSH_AUTH_SOCK` environment variable](https://developer.1password.com/docs/ssh/get-started#step-4-configure-your-ssh-or-git-client) (Mac and Linux only) and run:

ssh-add -l