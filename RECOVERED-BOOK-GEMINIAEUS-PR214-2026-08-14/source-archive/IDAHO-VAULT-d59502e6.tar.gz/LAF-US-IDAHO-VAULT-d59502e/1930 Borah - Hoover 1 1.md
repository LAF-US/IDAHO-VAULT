---
date: 1930-06-01
related:
- Henry
- President
- Washington
- William Borah
authority: LOGAN
---
!Herbert_Hoover_at_desk_with_group_standing_behind_him.jpg

*President Herbert Hoover at desk with group standing behind him, including members of his Cabinet and Senators: Sen. Joseph T. Robinson, Sec. Henry Stimson, Vice Pres. Charles Curtis, Sen. William Borah, Sec. Patrick J. Hurley, Sec. Charles F. Adams, Sen. James E. Watson, and Sen. David A. Reed*

---

[^1] *Harris & Ewing*. Washington, D.C., June 1930.

---
