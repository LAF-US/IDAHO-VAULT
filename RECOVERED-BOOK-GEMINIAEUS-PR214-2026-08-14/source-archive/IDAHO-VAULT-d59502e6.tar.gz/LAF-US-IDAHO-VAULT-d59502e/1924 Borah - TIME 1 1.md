---
date: 1924-05-05
---
!TIMEMagazine5May1924.jpg

---

[^1] Senator William E. Borah. *TIME Magazine*. May 5, 1924.

---
