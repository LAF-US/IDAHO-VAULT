---
author:
- Erica Curless
outlet:
- Spokesman-Review
URL: https://www.spokesman.com/stories/2004/sep/18/taxes-to-be-hot-topic-at-meeting/
related:
- '200'
- '213'
- '873'
- Association of Idaho Cities
- Boise
- Coeur d'Alene
- County Assessor
- County Commissioners
- Idaho
- Idaho Association of Counties
- Kootenai
- Kootenai County
- Post Falls
- Prairie
- Rathdrum
- Sandpoint
- Spokesman-Review
- cities
- costs
- counties
- district court
- election
- fire
- general election
- highways
- homeowners
- homes
- initial
- jails
- legislative
- libraries
- lobbying
- mayor
- meeting
- money
- police
- prices
- property tax
- roads
- sales tax
- tax exemptions
- taxes
- taxing districts
authority: LOGAN
---
Helping longtime residents afford the taxes on their homes could become a major topic of next week’s Idaho Association of Counties annual conference that will bring nearly 200 elected officials to Coeur d'Alene.

Kootenai County officials hope the association will come up with proposed legislation for the 2005 Legislature to help taxpayers all over Idaho, but especially in resort areas like Coeur d’Alene and Sandpoint.

Another big topic could be Kootenai County’s push to expand the half-cent local option tax to pay for projects other than jails. And Post Falls mayor Clay Larkin will make a plea for counties and cities to work more closely because they share many of the same concerns.

“The hot issues in the Legislature are always issues related to taxation,” Idaho Association of Counties Executive Director Dan Chadwick said. counties collect property taxes and then dole out the cash to taxing districts ranging from schools and fire to highways and libraries.

The conference gives members – including County Commissioners, assessors and clerks – a chance to set legislative priorities, network and attend training workshops while getting in a lake cruise and some golf. The conference starts Monday and runs through Thursday at the Coeur d’Alene Resort.

Kootenai County Assessor Mike McDowell has been tweaking a plan aimed at helping people who have owned and lived in their home for at least 10 years.

People paying inflated prices for property in Kootenai County and other resort towns are making it difficult for many residents, especially retirees on fixed incomes, to afford their property taxes. McDowell and other county officials agree the burden of new growth shouldn’t fall on the residents who have already paid their share of costs for roads, fire, police and other services over the years.

McDowell plans to pitch several options for stabilizing these longtime residents’ tax burden. It’s his hope the association will finalize the plan and turn it into a bill for legislators to consider.

“If we don’t have a proposal it will be whatever shape the Legislature decides,” McDowell said.

McDowell suggests that decade-long property owners could apply for an exemption that would freeze the value of their home until the property is sold. That means as the home’s value increases, the homeowner wouldn’t have to pay property taxes on that new value.

He estimates about 12,000 homeowners in Kootenai County could be eligible for the proposed exemption.

Several other variations have surfaced since McDowell presented his initial idea to the Idaho Association of Assessors in August.

McDowell said some officials want to look at giving the exemption to people who have owned their property for at least 20 years. Another suggestion is deferring the increase in property taxes until the land or home is sold. That means the county would still calculate the tax based on the new assessed market value. When that owner decided to sell the property, then the most current 10 years of deferred taxes would become due. The seller and new owner would have to work out who paid the taxes, McDowell said.

This option is popular with some people because it doesn’t shift the tax burden to other property taxpayers as much as the exemption option.

Net property values in Kootenai County increased about $873 million this year, bringing the county’s total to about $7.7 billion. New development in Kootenai County added $213 million to the county’s tax base this year, which is up about $63 million from last year.

The spike is a result of the strong real estate market along with low interest rates, McDowell said.

Generally, county officials don’t like property tax exemptions because they narrow the tax base and cause other property taxpayers to dole out more cash. Yet McDowell said the problem has gotten so bad in some Idaho counties that most officials know some sort of relief is needed.

Kootenai County Commissioner Gus Johnson, a member of the association’s Legislative Committee, also wants to get support for a bill to expand the local option tax. Currently Kootenai and Nez Perce counties charge an extra half-cent in sales tax to pay for jail expansions. Half of the money goes to property tax relief.

Kootenai County is leading the charge to expand the local option tax to pay for projects other than jails.

An advisory vote is on the November general election ballot that will gauge whether Kootenai County voters would support expanding the law. If voters agree, the county will use the results as a lobbying tool to show the Legislature that people want the ability to tax themselves for certain projects.

Regardless of the outcome, convincing the tax-averse Legislature to expand the law is a big hurdle because many Idaho lawmakers don’t like the idea of allowing counties to control sales tax collection.

Two ideas have emerged for how to use that extra sales-tax cash. Kootenai County Commission Chairman Dick Panabaker wants to use the half-cent sales tax to buy as much as 10,000 acres of Rathdrum Prairie for open space. He says the plan would protect the aquifer, decrease field burning, secure large amounts of open space and ensure the region’s ability to meet its growing wastewater treatment needs.

The other idea is to build a $32 million recreation and cultural civic center, which would have a pool, ice rink, and conference and performing arts space in addition to outdoor playing fields.

Those suggestions could only become reality if lawmakers agree to amend the law and local voters agree to keep the half-cent sales tax.

Johnson said another issue is getting cities to help counties pay district court costs.

“It’s a huge cost to us and cities use district court to try their cases,” Johnson said.

As a former Post Falls mayor, Johnson knows cities and counties should do a better job communicating because they often struggle with the same issues. That’s why he invited Post Falls mayor Clay Larkin, who recently became the Association of Idaho Cities president, to speak at the counties’ convention.

Larkin said the cities association just created a city-county task force and that the leaders of both groups will meet in Boise Oct. 8. If both associations, which both lobby the Legislature, could work together they could become more influential. The cities and counties represent the entire population of the state.

“That’s pretty powerful,” Larkin said.