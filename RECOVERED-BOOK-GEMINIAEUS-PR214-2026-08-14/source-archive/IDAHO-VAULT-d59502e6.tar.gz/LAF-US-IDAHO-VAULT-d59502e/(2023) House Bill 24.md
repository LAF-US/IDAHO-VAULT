---
cmte:
- House Commerce and Human Resources
- House Education
- Senate Commerce and Human Resources
URL: https://legislature.idaho.gov/sessioninfo/2023/legislation/h0024/
sponsor:
- Megan Blanksma
- Dave Lent
related:
- '174'
- DEVELOPMENT
- Dave Lent
- Governor
- Grant
- HUMAN
- House Commerce and Human Resources
- House Education
- Human Resources
- Idaho
- Idaho Launch
- JRA
- Megan Blanksma
- Mickelsen
- President
- Raymond
- Roberts
- Senate Commerce and Human Resources
- sunset clause
authority: LOGAN
---
by COMMERCE AND HUMAN RESOURCES COMMITTEE

WORKFORCE DEVELOPMENT – Amends and adds to existing law to establish the Idaho Launch Grant Program and to revise provisions regarding the In-Demand Careers Fund.

>
01/24 	Introduced, read first time, referred to JRA for Printing 	 
01/25 	Reported Printed and Referred to Education 	
02/01 	Reported out of Committee with Do Pass Recommendation, Filed for Second Reading 	 
02/02 	Read second time; Filed for Third Reading 	 
02/03 	U.C. to hold place on third reading calendar until Monday, February 6, 2023 	 
02/06 	Read Third Time in Full – PASSED - 36-34-0
	**AYES –** Allgood, Berch, Blanksma, Bundy, Burns, Cheatum, Chew, Clow, Dixon(24), Durrant, Erickson, Furniss, Galaviz, Gannon, Garner, Green, Handy, Hill, Lanting, Manwaring, Mathias, McCann, Mickelsen, Nash, Necochea, Nelsen, Petzke, Raybould, Raymond, Roberts, Rubel, Sauter, Weber, Wheeler, Wroten, Yamamoto
	**NAYS –** Alfieri, Andrus, Barbieri, Boyle, Cannon, Cornilles, Crane(12), Crane(13), Dixon(1), Ehardt, Ehlers, Gallagher, Hawkins, Healey(Galloway), Holtzclaw(Yorgason), Horman, Kingsley, Lambert, Mendive, Miller, Mitchell, Monks, Palmer, Pickett, Price, Redman, Scott, Shepherd, Skaug, Tanner, Vander Woude, Wisniewski, Young, Mr. Speaker
	**Absent –** None
	**Floor Sponsor -** Blanksma
Title apvd - to Senate 
02/07 	Received from the House passed; filed for first reading 	 
Introduced, read first time; referred to: Commerce & Human Resources 	 
03/08 	Reported out of committee; to 14th Order for amendment 	 
03/20 	Reported out without amendments; filed for second reading 	 
03/21 	Read second time; filed for Third Reading 	 
03/22 	Read third time in full – PASSED - 20-15-0
	**AYES –** Anthon, Bernt, Burtenshaw, Cook, Grow, Guthrie, Harris, Hartgen, Just, Lee, Lent, Rabe, Ruchti, Schroeder, Semmelroth, Taylor, VanOrden, Ward-Engelking, Winder, Wintrow
	**NAYS –** Adams, Bjerke, Carlson, Den Hartog, Foreman, Hart, Herndon, Lakey, Lenney, Nichols, Okuniewicz, Ricks, Toews, Trakel, Zuiderveld
	**Absent and excused –** None
	**Floor Sponsor -** Lent
Title apvd - to House 	 
Returned from Senate Passed; to JRA for Enrolling 	 
03/23 	Reported Enrolled; Signed by Speaker; Transmitted to Senate 	 
Received from the House enrolled/signed by Speaker 	 
Signed by President; returned to House 	 
Returned Signed by the President; Ordered Transmitted to Governor 	 
03/24 	Delivered to Governor at 4:53 p.m. on March 23, 2023 	 
03/29 	Reported Signed by Governor on March 28, 2023
	Session Law Chapter 174
    Effective: 07/01/2023;
    12/31/2027 sunset clause - SECTION 6