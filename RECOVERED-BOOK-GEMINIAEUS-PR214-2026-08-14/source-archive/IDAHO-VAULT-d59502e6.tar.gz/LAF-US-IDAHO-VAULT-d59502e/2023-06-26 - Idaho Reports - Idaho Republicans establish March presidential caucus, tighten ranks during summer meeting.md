---
author:
- Melissa Davlin
outlet:
- Idaho Reports
URL: https://blog.idahoreports.idahoptv.org/2023/06/26/idaho-republicans-establish-march-presidential-caucus-tighten-ranks-during-summer-meeting/
related:
- 2023 legislative session
- Bonner County
- Bonner County Daily Bee
- Bonner County Republican Central Committee
- Brad Little
- Challis
- Dorothy Moon
- GOP
- Glenneda Zuiderveld
- Idaho
- Idaho Reports
- Idaho Republican Party
- Idaho Young Republicans
- Lori McCann
- Maria Nate
- Mark Sauter
- Melissa Davlin
- Phil McGrane
- Ron Nate
- Secretary of State
- Tom Luna
- Twin Falls
- abortion
- central committees
- children
- counties
- election
- general election
- legislative
- legislative session
- libraries
- meeting
- party platform
- political parties
- presidential primary
- special session
- veto
- vocal
- voice
- voting
authority: LOGAN
---
During its summer meeting, the Idaho Republican Party easily passed a number of proposals that raised concerns among some long-time party members. While some Republicans praised the meeting as the most unified and well-organized the party has seen in a decade, others walked away worried leadership was shutting out dissent. 

Proposals passed include: 

- A resolution to allow central committees to summon Republican elected officials to potentially censure them for not adhering to the party platform, with multiple censures potentially resulting in those officials unable to run as Republicans in future elections; 

- A proposal to create a presidential caucus if the Legislature doesn’t call a special session to fix issues with moving the presidential primary from March to May; 

- Removing voting privileges from the Federation of Republican Women, Idaho Young Republicans, and Idaho College Republicans on the party executive committee; 

- A vote of no confidence for Gov. Brad Little for vetoing a bill that would allow citizens to sue libraries if their children are able to check out obscene material. The no confidence vote includes lawmakers who did not vote to override the veto; 

- Support for a constitutional amendment allowing political parties to control their own primary processes.  

## An early presidential caucus 

Among the most consequential decisions made on Saturday: Approving a March presidential caucus for the 2024 presidential candidate selection process.   

During the 2023 legislative session, lawmakers passed a bill to move the presidential primary from March to May, but due to a technical error in the bill, it simply eliminated the March election date without adding a new May date. A follow-up bill to correct the error passed the Senate but died during a House hearing.  

Secretary of State Phil McGrane said he attended the summer meeting to see what the party would do in terms of a presidential primary. McGrane has said without a special legislative session to add the May primary, Idaho won’t have the ability to nominate a presidential candidate in 2024. On Saturday, he told Idaho Reports that he does not see momentum to call lawmakers back to address the issue. 

“Where we are is certainly not what anyone intended,” McGrane said.  

In that vacuum, the Idaho Republican Party chose to hold a March presidential caucus instead of a May primary.  

“My preference is that Idahoans have the opportunity to vote, so I have a strong preference toward the primary and us trying to find a resolution,” McGrane said.  

Caucuses have a much lower participation rate than primaries, which allow early voting and absentee voting. Caucuses are a one-time event, precluding people who can’t attend in person at that specific time. 

But former state representative Ron Nate pointed out that the early March caucus date gives Idahoans a stronger voice in selecting a presidential candidate. Often, most of the rest of the country has gone through their selection process by the time Idaho holds its May primary, he said. At that point, the majority of presidential candidates have already been mathematically eliminated from contention.  

“The choice is really between having an early voice and having no voice,” Nate said.  

McGrane acknowledged that a caucus is better than having no solution. “I think given where they are, the caucus is the next best alternative,” he said. 

## Building consensus or eliminating dissent?  

In a Sunday interview with Idaho Reports, Nate praised Idaho Republican Party chairwoman Dorothy Moon for hosting a well-organized meeting.  

“It seems there is growing unification within the party,” Nate said.  

Tom Luna, immediate past chairman of the state party, disagreed.  

“What happened (this weekend) does not represent the majority of the Republican party,” Luna told Idaho Reports on Saturday. “But what it did represent was the majority of the people that showed up were those that were very well organized and intent on purging the party of people that do not agree with them 100 percent of the time, whether it’s on abortion or education, whether it’s on what they view as the proper role of government.” 

Luna pointed to vocal criticism of lawmakers and Gov. Brad Little as an example. Little won the 2022 Republican primary in most counties, and comfortably won the general election statewide, but many of those counties’ small number of Republican committee members aren’t Little supporters. That shows a disconnect between precinct leadership and the average Idaho Republican voter, Luna said.  

“Even when I was elected party chair, I recognized that it was hundreds of Republicans who voted for me,” Luna said. “You’ve got Brad Little who had tens of thousands of Republicans who voted for him.” 

Luna also took exception to the resolution allowing central committees to summon elected officials to question them, and potentially censure them, over their voting record.  

According to the resolution, upon receiving a petition, the central committees can now set a meeting to hear the alleged violations of the party platform and allow the GOP official to respond. A majority of the committee could vote to censure the official, and subsequent censures with a 60% majority could “remove Party support and prohibit the use of Republican Party identifiers on campaign information and advertising” during the individual’s current term and any other campaigns for five years.  

Luna said these officials have already been elected by the majority of people in that district, and the central committees are much smaller. “If this person doesn’t meet this small group of people’s standards, then they’re going to be punished? I mean it’s a politburo,” he said. He also pointed to the removal of voting rights from the three private groups who have traditionally voted on the executive committee.  

“They’ve marginalized young republicans, Republican women, and college Republicans, and they were successful,” Luna said.  

Nate countered that it’s the job of the state party to protect the Republican brand: Defense of small government, personal property rights, and the state and US constitutions.  

“To protect the brand, the party has adopted whatever measures it can to preserve party integrity,” Nate said, saying a number of Idaho Republicans no longer adhere to the party platform.

Sen. Glenneda Zuiderveld, R-Twin Falls, agreed. “Personally, I’m all for them keeping me accountable,” she said in a Monday interview with Idaho Reports.  Zuiderveld said she regularly hears from constituents that they’re concerned about lawmakers who stray from the platform, which the state party reconsiders and can amend every two years. It’s the local precincts’ responsibility to inform elected officials if they have concerns about their voting records, she said.

“The (precinct committeeman’s) job should be going out to their precincts, going and listening to them so they can report back to me,” she said.

Already, central committees can, and do, hold votes of no confidence over officials’ voting records. In April, the Bonner County Republican Central Committee held a vote of no confidence for Rep. Mark Sauter, according to the Bonner County Daily Bee. Rep. Lori McCann has also faced votes of no confidence. But until now, those votes carried no real repercussions.

Nate said ultimately, this move will help unify the party more.

“As the split in the party has grown over time where you have some who don’t follow the Republican platform, that has created the division,” he said.

Nate and Zuiderveld both said the meeting was far more civil than those in recent years, with nearly every proposal passing with a comfortable majority. 

“We had lively debate, but I don’t think we had as much sniping as there has been in the past,” said Nate, whose wife, Maria Nate, is the state party secretary. “It seems there is a growing unification in the party.” 

But Luna said the remote location of the summer meeting – located at Living Waters Ranch in Challis – made it difficult for more people to attend, and reiterated his belief that this set of party leadership was out of touch with most Idaho conservatives.  

“If I’m a Republican, I think it’s time to start paying a lot more attention to the kind of decisions that are being made by a small number of Republicans that are going to impact all of us,” Luna said.