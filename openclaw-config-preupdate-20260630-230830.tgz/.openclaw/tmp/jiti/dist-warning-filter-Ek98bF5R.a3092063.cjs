"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.n = shouldIgnoreWarning;exports.t = installProcessWarningFilter;var _globalSingletonDE6St75u = require("./global-singleton-DE6St75u.js");
//#region src/infra/warning-filter.ts
const warningFilterKey = Symbol.for("openclaw.warning-filter");
function shouldIgnoreWarning(warning) {
  if (warning.code === "DEP0040" && warning.message?.includes("punycode")) return true;
  if (warning.code === "DEP0060" && warning.message?.includes("util._extend")) return true;
  if (warning.name === "ExperimentalWarning" && warning.message?.includes("SQLite is an experimental feature")) return true;
  return false;
}
function normalizeWarningArgs(args) {
  const warningArg = args[0];
  const secondArg = args[1];
  const thirdArg = args[2];
  let name;
  let code;
  let message;
  if (warningArg instanceof Error) {
    name = warningArg.name;
    message = warningArg.message;
    code = warningArg.code;
  } else if (typeof warningArg === "string") message = warningArg;
  if (secondArg && typeof secondArg === "object" && !Array.isArray(secondArg)) {
    const options = secondArg;
    if (typeof options.type === "string") name = options.type;
    if (typeof options.code === "string") code = options.code;
  } else {
    if (typeof secondArg === "string") name = secondArg;
    if (typeof thirdArg === "string") code = thirdArg;
  }
  return {
    name,
    code,
    message
  };
}
function installProcessWarningFilter() {
  const state = (0, _globalSingletonDE6St75u.n)(warningFilterKey, () => ({ installed: false }));
  if (state.installed) return;
  const originalEmitWarning = process.emitWarning.bind(process);
  const wrappedEmitWarning = (...args) => {
    if (shouldIgnoreWarning(normalizeWarningArgs(args))) return;
    if (args[0] instanceof Error && args[1] && typeof args[1] === "object" && !Array.isArray(args[1])) {
      const warning = args[0];
      const emitted = Object.assign(new Error(warning.message), {
        name: warning.name,
        code: warning.code
      });
      process.emit("warning", emitted);
      return;
    }
    Reflect.apply(originalEmitWarning, process, args);
  };
  process.emitWarning = wrappedEmitWarning;
  state.installed = true;
}
//#endregion /* v9-76429b86f1c45ac7 */
