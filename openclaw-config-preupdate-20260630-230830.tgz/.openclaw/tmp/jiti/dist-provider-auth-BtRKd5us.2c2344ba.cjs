"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.a = listUsableProviderAuthProfileIds;exports.c = generateHexPkceVerifierChallenge;exports.i = isProviderAuthProfileConfigured;exports.l = generatePkceVerifierChallenge;exports.n = deriveCopilotApiBaseUrlFromToken;exports.o = resolveCopilotApiToken;exports.r = isProviderApiKeyConfigured;exports.s = resolveProviderAuthProfileApiKey;exports.t = void 0;exports.u = toFormUrlEncoded;var _stringCoerceDyL154ka = require("./string-coerce-DyL154ka.js");
var _pathsCw7f9XhU = require("./paths-Cw7f9XhU.js");
require("./types.secrets-DwPik3M8.js");
var _agentScopeConfigCMp71_ = require("./agent-scope-config-CMp71_27.js");
var _jsonFileDpLhTVdZ = require("./json-file-DpLhTVdZ.js");
require("./ref-contract-D_h_G00C.js");
require("./provider-env-vars-HpAfBQBJ.js");
require("./constants-D_82oc2f.js");
var _storeBMQkMM4l = require("./store-BMQkMM4l.js");
require("./model-auth-markers-Cf78z2Zm.js");
var _modelAuthEnvCZLXyVa = require("./model-auth-env-CZ-LXyVa.js");
require("./models-config.providers.secrets-k1Lv9zej.js");
var _providerAttributionB2QMzk1g = require("./provider-attribution-B2QMzk1g.js");
var _oauthYqMDDjF = require("./oauth--yqMDDjF.js");
var _profileListC0HtPlut = require("./profile-list-C0HtPlut.js");
require("./profiles-9GB1thhi.js");
require("./repair-BQzHL5co.js");
var _orderDJrj83KE = require("./order-DJrj83KE.js");
var _copilotDynamicHeadersCVy4X1Kj = require("./copilot-dynamic-headers-CVy4X1Kj.js");
require("./provider-model-shared-DtsPmvDx.js");
require("./provider-auth-input-DMNIEm93.js");
require("./provider-auth-helpers-BZ5Z8RV6.js");
require("./provider-api-key-auth-E_5Yag4W.js");
require("./agent-dir-compat-_xK_EqIx.js");
require("./provider-auth-result-qR7142tf.js");
var _nodePath = _interopRequireDefault(require("node:path"));
var _nodeCrypto = require("node:crypto");function _interopRequireDefault(e) {return e && e.__esModule ? e : { default: e };}
//#region src/plugin-sdk/oauth-utils.ts
/**
* Encode a flat object as application/x-www-form-urlencoded form data.
*
* @deprecated OAuth provider-owned helper; keep this local to provider plugins instead.
*/
function toFormUrlEncoded(data) {
  return Object.entries(data).map(([key, value]) => `${encodeURIComponent(key)}=${encodeURIComponent(value)}`).join("&");
}
/**
* Generate a PKCE verifier/challenge pair suitable for OAuth authorization flows.
*
* @deprecated OAuth provider-owned helper; keep this local to provider plugins instead.
*/
function generatePkceVerifierChallenge() {
  const verifier = (0, _nodeCrypto.randomBytes)(32).toString("base64url");
  return {
    verifier,
    challenge: (0, _nodeCrypto.createHash)("sha256").update(verifier).digest("base64url")
  };
}
/** Generate a PKCE verifier/challenge pair with a 64-character hex verifier. */
function generateHexPkceVerifierChallenge() {
  const verifier = (0, _nodeCrypto.randomBytes)(32).toString("hex");
  return {
    verifier,
    challenge: (0, _nodeCrypto.createHash)("sha256").update(verifier).digest("base64url")
  };
}
//#endregion
//#region src/plugin-sdk/provider-auth.ts
const COPILOT_TOKEN_URL = "https://api.github.com/copilot_internal/v2/token";
/** @deprecated GitHub Copilot provider-owned helper; do not use from third-party plugins. */
const DEFAULT_COPILOT_API_BASE_URL = exports.t = "https://api.individual.githubcopilot.com";
function resolveCopilotTokenCachePath(env = process.env) {
  return _nodePath.default.join((0, _pathsCw7f9XhU.y)(env), "credentials", "github-copilot.token.json");
}
function isCopilotTokenUsable(cache, now = Date.now()) {
  return cache.integrationId === "vscode-chat" && cache.expiresAt - now > 300 * 1e3;
}
function parseCopilotTokenResponse(value) {
  if (!value || typeof value !== "object") throw new Error("Unexpected response from GitHub Copilot token endpoint");
  const asRecord = value;
  const token = asRecord.token;
  const expiresAt = asRecord.expires_at;
  if (typeof token !== "string" || token.trim().length === 0) throw new Error("Copilot token response missing token");
  let expiresAtMs;
  if (typeof expiresAt === "number" && Number.isFinite(expiresAt)) expiresAtMs = expiresAt < 1e11 ? expiresAt * 1e3 : expiresAt;else
  if (typeof expiresAt === "string" && expiresAt.trim().length > 0) {
    const parsed = Number.parseInt(expiresAt, 10);
    if (!Number.isFinite(parsed)) throw new Error("Copilot token response has invalid expires_at");
    expiresAtMs = parsed < 1e11 ? parsed * 1e3 : parsed;
  } else throw new Error("Copilot token response missing expires_at");
  return {
    token,
    expiresAt: expiresAtMs
  };
}
function resolveCopilotProxyHost(proxyEp) {
  const trimmed = proxyEp.trim();
  if (!trimmed) return null;
  const urlText = /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
  try {
    const url = new URL(urlText);
    if (url.protocol !== "http:" && url.protocol !== "https:") return null;
    return (0, _stringCoerceDyL154ka.a)(url.hostname);
  } catch {
    return null;
  }
}
/** @deprecated GitHub Copilot provider-owned helper; do not use from third-party plugins. */
function deriveCopilotApiBaseUrlFromToken(token) {
  const trimmed = token.trim();
  if (!trimmed) return null;
  const proxyEp = trimmed.match(/(?:^|;)\s*proxy-ep=([^;\s]+)/i)?.[1]?.trim();
  if (!proxyEp) return null;
  const proxyHost = resolveCopilotProxyHost(proxyEp);
  if (!proxyHost) return null;
  const baseUrl = `https://${proxyHost.replace(/^proxy\./i, "api.")}`;
  return (0, _providerAttributionB2QMzk1g.n)(baseUrl).endpointClass === "invalid" ? null : baseUrl;
}
/** @deprecated GitHub Copilot provider-owned helper; do not use from third-party plugins. */
async function resolveCopilotApiToken(params) {
  const env = params.env ?? process.env;
  const cachePath = params.cachePath?.trim() || resolveCopilotTokenCachePath(env);
  const loadJsonFileFn = params.loadJsonFileImpl ?? _jsonFileDpLhTVdZ.t;
  const saveJsonFileFn = params.saveJsonFileImpl ?? _jsonFileDpLhTVdZ.n;
  const cached = loadJsonFileFn(cachePath);
  if (cached && typeof cached.token === "string" && typeof cached.expiresAt === "number") {
    if (isCopilotTokenUsable(cached)) return {
      token: cached.token,
      expiresAt: cached.expiresAt,
      source: `cache:${cachePath}`,
      baseUrl: deriveCopilotApiBaseUrlFromToken(cached.token) ?? "https://api.individual.githubcopilot.com"
    };
  }
  const res = await (params.fetchImpl ?? fetch)(COPILOT_TOKEN_URL, {
    method: "GET",
    headers: {
      Accept: "application/json",
      Authorization: `Bearer ${params.githubToken}`,
      "Copilot-Integration-Id": _copilotDynamicHeadersCVy4X1Kj.i,
      ...(0, _copilotDynamicHeadersCVy4X1Kj.s)({ includeApiVersion: true })
    }
  });
  if (!res.ok) throw new Error(`Copilot token exchange failed: HTTP ${res.status}`);
  const json = parseCopilotTokenResponse(await res.json());
  const payload = {
    token: json.token,
    expiresAt: json.expiresAt,
    updatedAt: Date.now(),
    integrationId: _copilotDynamicHeadersCVy4X1Kj.i
  };
  saveJsonFileFn(cachePath, payload);
  return {
    token: payload.token,
    expiresAt: payload.expiresAt,
    source: `fetched:${COPILOT_TOKEN_URL}`,
    baseUrl: deriveCopilotApiBaseUrlFromToken(payload.token) ?? "https://api.individual.githubcopilot.com"
  };
}
function isProviderApiKeyConfigured(params) {
  if ((0, _modelAuthEnvCZLXyVa.t)(params.provider)?.apiKey) return true;
  const agentDir = params.agentDir?.trim();
  if (!agentDir) return false;
  return (0, _profileListC0HtPlut.n)((0, _storeBMQkMM4l.n)(agentDir, { allowKeychainPrompt: false }), params.provider).length > 0;
}
function listUsableProviderAuthProfileIds(params) {
  try {
    const { agentDir, profileIds } = resolveUsableProviderAuthProfiles(params);
    return {
      agentDir,
      profileIds
    };
  } catch {
    return {
      agentDir: "",
      profileIds: []
    };
  }
}
function isProviderAuthProfileConfigured(params) {
  return listUsableProviderAuthProfileIds(params).profileIds.length > 0;
}
async function resolveProviderAuthProfileApiKey(params) {
  const { agentDir, profileIds, store } = resolveUsableProviderAuthProfiles(params);
  if (!agentDir || profileIds.length === 0) return;
  for (const profileId of profileIds) {
    const resolved = await (0, _oauthYqMDDjF.n)({
      cfg: params.cfg,
      store,
      agentDir,
      profileId
    });
    if (resolved?.apiKey) return resolved.apiKey;
  }
}
function resolveUsableProviderAuthProfiles(params) {
  const agentDir = params.agentDir?.trim() || (0, _agentScopeConfigCMp71_.s)(params.cfg ?? {});
  const store = (0, _storeBMQkMM4l.c)(agentDir);
  const profileIds = (0, _orderDJrj83KE.i)({
    cfg: params.cfg,
    store,
    provider: params.provider
  });
  if (profileIds.length > 0) return {
    agentDir,
    profileIds,
    store
  };
  const fallbackStore = (0, _storeBMQkMM4l.l)(agentDir, {
    allowKeychainPrompt: params.allowKeychainPrompt ?? false,
    resolveLegacyOAuthSidecars: true
  });
  return {
    agentDir,
    profileIds: (0, _orderDJrj83KE.i)({
      cfg: params.cfg,
      store: fallbackStore,
      provider: params.provider
    }),
    store: fallbackStore
  };
}
//#endregion /* v9-25e394545b323296 */
