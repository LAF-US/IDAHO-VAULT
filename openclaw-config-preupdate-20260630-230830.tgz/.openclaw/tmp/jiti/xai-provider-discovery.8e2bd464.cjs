"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.default = void 0;var _webSearchProviderCommonDg4Eh9ob = require("../../web-search-provider-common-Dg4Eh9ob.js");
require("../../provider-web-search-DNIStESL.js");
var _toolAuthShared1307PZ = require("../../tool-auth-shared-1307P-Z2.js");
//#region extensions/xai/provider-discovery.ts
const PROVIDER_ID = "xai";
function resolveXaiSyntheticAuth(config) {
  const apiKey = (0, _toolAuthShared1307PZ.n)(config)?.apiKey || (0, _webSearchProviderCommonDg4Eh9ob.p)(["XAI_API_KEY"]);
  return apiKey ? {
    apiKey,
    source: "xAI plugin config",
    mode: "api-key"
  } : void 0;
}
const xaiProviderDiscovery = exports.default = {
  id: PROVIDER_ID,
  label: "xAI",
  docsPath: "/providers/models",
  auth: [],
  resolveSyntheticAuth: ({ config }) => resolveXaiSyntheticAuth(config)
};
//#endregion /* v9-f348c5ef337fed18 */
