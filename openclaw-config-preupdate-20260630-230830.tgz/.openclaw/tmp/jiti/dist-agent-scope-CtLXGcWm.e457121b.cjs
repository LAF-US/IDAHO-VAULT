"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.C = hasSessionAutoModelFallbackProvenance;exports.S = setAgentEffectiveModelPrimary;exports._ = resolveSessionAgentId;exports.a = resolveAgentEffectiveModelPrimary;exports.b = resolveSubagentModelConfigSelectionResult;exports.c = resolveAgentIdByWorkspacePath;exports.d = resolveAgentModelPrimary;exports.f = resolveAgentSkillsFilter;exports.g = resolveRunModelFallbacksOverride;exports.h = resolveFallbackAgentId;exports.i = markAutoFallbackPrimaryProbe;exports.l = resolveAgentIdsByWorkspacePath;exports.m = resolveEffectiveModelFallbacks;exports.n = entryMatchesAutoFallbackPrimaryProbe;exports.o = resolveAgentExecutionContract;exports.p = resolveAutoFallbackPrimaryProbe;exports.r = hasConfiguredModelFallbacks;exports.s = resolveAgentExplicitModelPrimary;exports.t = clearAutoFallbackPrimaryProbeSelection;exports.u = resolveAgentModelFallbacksOverride;exports.v = resolveSessionAgentIds;exports.x = resolveSubagentModelFallbacksOverride;exports.y = resolveSubagentModelConfigSelection;var _stringCoerceDyL154ka = require("./string-coerce-DyL154ka.js");
var _pathBlG8lhgR = require("./path-BlG8lhgR.js");
var _utilsSBTEdeml = require("./utils-sBTEdeml.js");
var _modelInputChW9XXsQ = require("./model-input-ChW9XXsQ.js");
require("./path-guards-CBe_wA_B.js");
var _sessionKeyUtilsCe_xWkNq = require("./session-key-utils-Ce_xWkNq.js");
var _sessionKeyBte0mmcq = require("./session-key-Bte0mmcq.js");
var _agentScopeConfigCMp71_ = require("./agent-scope-config-CMp71_27.js");
var _agentFilterCZoQBzQY = require("./agent-filter-CZoQBzQY.js");
var _nodeFs = _interopRequireDefault(require("node:fs"));
var _nodePath = _interopRequireDefault(require("node:path"));function _interopRequireDefault(e) {return e && e.__esModule ? e : { default: e };}
//#region src/config/sessions/model-override-provenance.ts
function hasSessionAutoModelFallbackProvenance(entry) {
  const hasActiveOverride = Boolean((0, _stringCoerceDyL154ka.c)(entry?.providerOverride) || (0, _stringCoerceDyL154ka.c)(entry?.modelOverride));
  return Boolean(hasActiveOverride && (0, _stringCoerceDyL154ka.c)(entry?.modelOverrideFallbackOriginProvider) && (0, _stringCoerceDyL154ka.c)(entry?.modelOverrideFallbackOriginModel));
}
//#endregion
//#region src/agents/agent-scope.ts
/** Strip null bytes from paths to prevent ENOTDIR errors. */
function stripNullBytes(s) {
  return s.replace(/\0/g, "");
}
const AUTO_FALLBACK_PRIMARY_PROBE_INTERVAL_MS = 300 * 1e3;
const AUTO_FALLBACK_PRIMARY_PROBE_MAX_KEYS = 4096;
const autoFallbackPrimaryProbeState = /* @__PURE__ */new Map();
function autoFallbackPrimaryProbeStateKey(params) {
  return [(0, _stringCoerceDyL154ka.c)(params.sessionKey) ?? "", `${params.primaryProvider}/${params.primaryModel}`].join("\0");
}
function pruneAutoFallbackPrimaryProbeState(params) {
  const maxKeys = Math.max(1, Math.trunc(params.maxKeys ?? AUTO_FALLBACK_PRIMARY_PROBE_MAX_KEYS));
  const staleBefore = params.now - params.minIntervalMs;
  for (const [key, lastProbeAt] of params.state) if (!Number.isFinite(lastProbeAt) || lastProbeAt < staleBefore) params.state.delete(key);
  if (params.state.size <= maxKeys) return;
  const removeCount = params.state.size - maxKeys;
  let removed = 0;
  for (const key of params.state.keys()) {
    params.state.delete(key);
    removed += 1;
    if (removed >= removeCount) break;
  }
}
function resolveAutoFallbackPrimaryProbe(params) {
  const entry = params.entry;
  if (!entry) return;
  const recoveredAutoFallbackOverride = entry.modelOverrideSource === void 0 && hasSessionAutoModelFallbackProvenance(entry);
  if (entry.modelOverrideSource !== "auto" && !recoveredAutoFallbackOverride) return;
  const originProvider = (0, _stringCoerceDyL154ka.c)(entry.modelOverrideFallbackOriginProvider);
  const originModel = (0, _stringCoerceDyL154ka.c)(entry.modelOverrideFallbackOriginModel);
  const overrideProvider = (0, _stringCoerceDyL154ka.c)(entry.providerOverride);
  const overrideModel = (0, _stringCoerceDyL154ka.c)(entry.modelOverride);
  const primaryProvider = (0, _stringCoerceDyL154ka.c)(params.primaryProvider);
  const primaryModel = (0, _stringCoerceDyL154ka.c)(params.primaryModel);
  if (!originProvider || !originModel || !overrideProvider || !overrideModel) return;
  if (!primaryProvider || !primaryModel) return;
  if (originProvider !== primaryProvider || originModel !== primaryModel) return;
  if (overrideProvider === originProvider && overrideModel === originModel) return;
  const now = params.now ?? Date.now();
  const minIntervalMs = params.minIntervalMs ?? AUTO_FALLBACK_PRIMARY_PROBE_INTERVAL_MS;
  const state = params.probeState ?? autoFallbackPrimaryProbeState;
  pruneAutoFallbackPrimaryProbeState({
    state,
    now,
    minIntervalMs,
    maxKeys: params.maxTrackedProbeKeys
  });
  const key = autoFallbackPrimaryProbeStateKey({
    sessionKey: params.sessionKey,
    primaryProvider: originProvider,
    primaryModel: originModel
  });
  const lastProbeAt = state.get(key);
  if (typeof lastProbeAt === "number" && Number.isFinite(lastProbeAt) && now - lastProbeAt < minIntervalMs) return;
  const fallbackAuthProfileId = (0, _stringCoerceDyL154ka.c)(entry.authProfileOverride);
  const fallbackAuthProfileIdSource = entry.authProfileOverrideSource ?? (entry.authProfileOverrideCompactionCount !== void 0 ? "auto" : void 0);
  return {
    provider: originProvider,
    model: originModel,
    fallbackProvider: overrideProvider,
    fallbackModel: overrideModel,
    ...(fallbackAuthProfileId ? {
      fallbackAuthProfileId,
      ...(fallbackAuthProfileIdSource ? { fallbackAuthProfileIdSource } : {})
    } : {})
  };
}
function markAutoFallbackPrimaryProbe(params) {
  const now = params.now ?? Date.now();
  const minIntervalMs = params.minIntervalMs ?? AUTO_FALLBACK_PRIMARY_PROBE_INTERVAL_MS;
  const state = params.probeState ?? autoFallbackPrimaryProbeState;
  pruneAutoFallbackPrimaryProbeState({
    state,
    now,
    minIntervalMs,
    maxKeys: params.maxTrackedProbeKeys
  });
  const key = autoFallbackPrimaryProbeStateKey({
    sessionKey: params.sessionKey,
    primaryProvider: params.probe.provider,
    primaryModel: params.probe.model
  });
  state.set(key, now);
  pruneAutoFallbackPrimaryProbeState({
    state,
    now,
    minIntervalMs,
    maxKeys: params.maxTrackedProbeKeys
  });
}
function entryMatchesAutoFallbackPrimaryProbe(entry, probe) {
  if (!entry) return false;
  const recoveredAutoFallbackOverride = entry.modelOverrideSource === void 0 && hasSessionAutoModelFallbackProvenance(entry);
  if (entry.modelOverrideSource !== "auto" && !recoveredAutoFallbackOverride) return false;
  return (0, _stringCoerceDyL154ka.c)(entry.providerOverride) === probe.fallbackProvider && (0, _stringCoerceDyL154ka.c)(entry.modelOverride) === probe.fallbackModel && (0, _stringCoerceDyL154ka.c)(entry.modelOverrideFallbackOriginProvider) === probe.provider && (0, _stringCoerceDyL154ka.c)(entry.modelOverrideFallbackOriginModel) === probe.model;
}
function clearAutoFallbackPrimaryProbeSelection(entry, now = Date.now()) {
  delete entry.providerOverride;
  delete entry.modelOverride;
  delete entry.modelOverrideSource;
  delete entry.modelOverrideFallbackOriginProvider;
  delete entry.modelOverrideFallbackOriginModel;
  if (entry.authProfileOverrideSource === "auto" || entry.authProfileOverrideSource === void 0 && entry.authProfileOverrideCompactionCount !== void 0) {
    delete entry.authProfileOverride;
    delete entry.authProfileOverrideSource;
    delete entry.authProfileOverrideCompactionCount;
  }
  delete entry.fallbackNoticeSelectedModel;
  delete entry.fallbackNoticeActiveModel;
  delete entry.fallbackNoticeReason;
  entry.updatedAt = now;
}
function resolveSessionAgentIds(params) {
  const defaultAgentId = (0, _agentScopeConfigCMp71_.c)(params.config ?? {});
  const explicitAgentIdRaw = (0, _stringCoerceDyL154ka.a)(params.agentId);
  const explicitAgentId = explicitAgentIdRaw ? (0, _sessionKeyBte0mmcq.l)(explicitAgentIdRaw) : null;
  const sessionKey = params.sessionKey?.trim();
  const normalizedSessionKey = sessionKey ? (0, _stringCoerceDyL154ka.a)(sessionKey) : void 0;
  const parsed = normalizedSessionKey ? (0, _sessionKeyUtilsCe_xWkNq.c)(normalizedSessionKey) : null;
  return {
    defaultAgentId,
    sessionAgentId: explicitAgentId ?? (parsed?.agentId ? (0, _sessionKeyBte0mmcq.l)(parsed.agentId) : defaultAgentId)
  };
}
function resolveSessionAgentId(params) {
  return resolveSessionAgentIds(params).sessionAgentId;
}
function resolveAgentExecutionContract(cfg, agentId) {
  const defaultContract = cfg?.agents?.defaults?.embeddedPi?.executionContract;
  if (!cfg || !agentId) return defaultContract;
  return (0, _agentScopeConfigCMp71_.r)(cfg, agentId)?.embeddedPi?.executionContract ?? defaultContract;
}
function resolveAgentSkillsFilter(cfg, agentId) {
  return (0, _agentFilterCZoQBzQY.t)(cfg, agentId);
}
function resolveAgentExplicitModelPrimary(cfg, agentId) {
  const raw = (0, _agentScopeConfigCMp71_.r)(cfg, agentId)?.model;
  return (0, _stringCoerceDyL154ka.p)(raw);
}
function resolveAgentEffectiveModelPrimary(cfg, agentId) {
  return resolveAgentExplicitModelPrimary(cfg, agentId) ?? (0, _stringCoerceDyL154ka.p)(cfg.agents?.defaults?.model);
}
function findMutableAgentEntry(cfg, agentId) {
  const id = (0, _sessionKeyBte0mmcq.l)(agentId);
  return cfg.agents?.list?.find((entry) => (0, _sessionKeyBte0mmcq.l)(entry?.id) === id);
}
function updateAgentModelPrimary(existing, primary) {
  if (existing && typeof existing === "object" && !Array.isArray(existing)) return {
    ...existing,
    primary
  };
  return primary;
}
function setAgentEffectiveModelPrimary(cfg, agentId, primary) {
  const id = (0, _sessionKeyBte0mmcq.l)(agentId);
  if (resolveAgentExplicitModelPrimary(cfg, id)) {
    const entry = findMutableAgentEntry(cfg, id);
    if (entry) {
      entry.model = updateAgentModelPrimary(entry.model, primary);
      return "agent";
    }
  }
  cfg.agents ??= {};
  cfg.agents.defaults ??= {};
  cfg.agents.defaults.model = updateAgentModelPrimary(cfg.agents.defaults.model, primary);
  return "defaults";
}
/** @deprecated Prefer explicit/effective helpers at new call sites. */
function resolveAgentModelPrimary(cfg, agentId) {
  return resolveAgentExplicitModelPrimary(cfg, agentId);
}
function resolveAgentModelFallbacksOverride(cfg, agentId) {
  return resolveSelectedModelFallbacksOverride((0, _agentScopeConfigCMp71_.r)(cfg, agentId)?.model);
}
function resolveSelectedModelFallbacksOverride(raw) {
  if (!raw) return;
  if (typeof raw === "string") return (0, _stringCoerceDyL154ka.p)(raw) ? [] : void 0;
  if (!Object.hasOwn(raw, "fallbacks")) return Object.hasOwn(raw, "primary") && (0, _stringCoerceDyL154ka.p)(raw) ? [] : void 0;
  return Array.isArray(raw.fallbacks) ? raw.fallbacks : void 0;
}
function resolveFirstModelFallbacksOverride(candidates) {
  for (const candidate of candidates) {
    const fallbackOverride = resolveSelectedModelFallbacksOverride(candidate);
    if (fallbackOverride !== void 0) return fallbackOverride;
  }
}
function resolveSubagentModelConfigSelectionResult(params) {
  const agentConfig = params.agentConfigOverride ?? (params.agentId ? (0, _agentScopeConfigCMp71_.r)(params.cfg, params.agentId) : void 0);
  return [
  ...(agentConfig?.subagents?.model ? [{
    raw: agentConfig.subagents.model,
    source: "subagent"
  }] : []),
  ...(agentConfig?.model ? [{
    raw: agentConfig.model,
    source: "agent"
  }] : []),
  ...(params.cfg.agents?.defaults?.subagents?.model ? [{
    raw: params.cfg.agents.defaults.subagents.model,
    source: "default-subagent"
  }] : [])].
  find((candidate) => (0, _stringCoerceDyL154ka.p)(candidate.raw));
}
function resolveSubagentModelConfigSelection(params) {
  return resolveSubagentModelConfigSelectionResult(params)?.raw;
}
function resolveSubagentModelFallbacksOverride(cfg, agentId) {
  const agentConfig = (0, _agentScopeConfigCMp71_.r)(cfg, agentId);
  const subagentFallbacks = resolveSelectedModelFallbacksOverride(agentConfig?.subagents?.model);
  if (subagentFallbacks !== void 0) return subagentFallbacks;
  const selection = resolveSubagentModelConfigSelectionResult({
    cfg,
    agentId
  });
  if (selection?.source === "agent") return resolveSelectedModelFallbacksOverride(agentConfig?.model);
  if (selection?.source === "default-subagent") return resolveSelectedModelFallbacksOverride(cfg.agents?.defaults?.subagents?.model);
}
function resolveSubagentSpawnModelFallbacksOverride(cfg, agentId) {
  const agentConfig = (0, _agentScopeConfigCMp71_.r)(cfg, agentId);
  return resolveFirstModelFallbacksOverride([
  agentConfig?.subagents?.model,
  cfg.agents?.defaults?.subagents?.model,
  agentConfig?.model]
  );
}
function resolveFallbackAgentId(params) {
  const explicitAgentId = (0, _stringCoerceDyL154ka.c)(params.agentId) ?? "";
  if (explicitAgentId) return (0, _sessionKeyBte0mmcq.l)(explicitAgentId);
  return (0, _sessionKeyBte0mmcq.d)(params.sessionKey);
}
function resolveRunModelFallbacksOverride(params) {
  if (!params.cfg) return;
  return resolveAgentModelFallbacksOverride(params.cfg, resolveFallbackAgentId({
    agentId: params.agentId,
    sessionKey: params.sessionKey
  }));
}
function hasConfiguredModelFallbacks(params) {
  const fallbacksOverride = resolveRunModelFallbacksOverride(params);
  const defaultFallbacks = (0, _modelInputChW9XXsQ.r)(params.cfg?.agents?.defaults?.model);
  return (fallbacksOverride ?? defaultFallbacks).length > 0;
}
function resolveEffectiveModelFallbacks(params) {
  const agentFallbacksOverride = resolveAgentModelFallbacksOverride(params.cfg, params.agentId);
  if (!params.hasSessionModelOverride) return agentFallbacksOverride;
  if (!(params.modelOverrideSource === "auto" || params.modelOverrideSource === void 0 && params.hasAutoFallbackProvenance === true)) return [];
  const subagentFallbacksOverride = (0, _sessionKeyUtilsCe_xWkNq.a)(params.sessionKey) ? resolveSubagentSpawnModelFallbacksOverride(params.cfg, params.agentId) : void 0;
  if (subagentFallbacksOverride !== void 0) return subagentFallbacksOverride;
  const defaultFallbacks = (0, _modelInputChW9XXsQ.r)(params.cfg.agents?.defaults?.model);
  return agentFallbacksOverride ?? defaultFallbacks;
}
function normalizePathForComparison(input) {
  const resolved = _nodePath.default.resolve(stripNullBytes((0, _utilsSBTEdeml.p)(input)));
  let normalized = resolved;
  try {
    normalized = _nodeFs.default.realpathSync.native(resolved);
  } catch {}
  if (process.platform === "win32") return (0, _stringCoerceDyL154ka.r)(normalized);
  return normalized;
}
function resolveAgentIdsByWorkspacePath(cfg, workspacePath) {
  const normalizedWorkspacePath = normalizePathForComparison(workspacePath);
  const ids = (0, _agentScopeConfigCMp71_.n)(cfg);
  const matches = [];
  for (let index = 0; index < ids.length; index += 1) {
    const id = ids[index];
    const workspaceDir = normalizePathForComparison((0, _agentScopeConfigCMp71_.o)(cfg, id));
    if (!(0, _pathBlG8lhgR.i)(workspaceDir, normalizedWorkspacePath)) continue;
    matches.push({
      id,
      workspaceDir,
      order: index
    });
  }
  matches.sort((left, right) => {
    const workspaceLengthDelta = right.workspaceDir.length - left.workspaceDir.length;
    if (workspaceLengthDelta !== 0) return workspaceLengthDelta;
    return left.order - right.order;
  });
  return matches.map((entry) => entry.id);
}
function resolveAgentIdByWorkspacePath(cfg, workspacePath) {
  return resolveAgentIdsByWorkspacePath(cfg, workspacePath)[0];
}
//#endregion /* v9-1b45bb9ebe50c102 */
