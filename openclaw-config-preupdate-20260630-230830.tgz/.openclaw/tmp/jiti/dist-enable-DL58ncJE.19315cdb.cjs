"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.t = enablePluginInConfig;var _idsBE_yccbC = require("./ids-BE_yccbC.js");
var _toggleConfigDID_OgqP = require("./toggle-config-DID_OgqP.js");
//#region src/plugins/enable.ts
function enablePluginInConfig(cfg, pluginId, options = {}) {
  const resolvedId = (0, _idsBE_yccbC.r)(pluginId) ?? pluginId;
  if (cfg.plugins?.enabled === false) return {
    config: cfg,
    enabled: false,
    pluginId: resolvedId,
    reason: "plugins disabled"
  };
  if (cfg.plugins?.deny?.includes(pluginId) || cfg.plugins?.deny?.includes(resolvedId)) return {
    config: cfg,
    enabled: false,
    pluginId: resolvedId,
    reason: "blocked by denylist"
  };
  const allow = cfg.plugins?.allow;
  if (Array.isArray(allow) && allow.length > 0 && !allow.includes(pluginId) && !allow.includes(resolvedId)) return {
    config: cfg,
    enabled: false,
    pluginId: resolvedId,
    reason: "blocked by allowlist"
  };
  return {
    config: (0, _toggleConfigDID_OgqP.t)(cfg, resolvedId, true, options),
    enabled: true,
    pluginId: resolvedId
  };
}
//#endregion /* v9-c39eb389a1ac1163 */
