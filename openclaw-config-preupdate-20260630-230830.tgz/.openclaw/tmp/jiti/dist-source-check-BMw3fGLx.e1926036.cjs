"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.t = hasAnyAuthProfileStoreSource;var _runtimeSnapshotsEsDr_mQ_ = require("./runtime-snapshots-esDr_mQ_.js");
var _pathResolveC6Vj5eOM = require("./path-resolve-C6Vj5eOM.js");
var _nodeFs = _interopRequireDefault(require("node:fs"));function _interopRequireDefault(e) {return e && e.__esModule ? e : { default: e };}
//#region src/agents/auth-profiles/source-check.ts
function hasStoredAuthProfileFiles(agentDir) {
  return _nodeFs.default.existsSync((0, _pathResolveC6Vj5eOM.r)(agentDir)) || _nodeFs.default.existsSync((0, _pathResolveC6Vj5eOM.t)(agentDir)) || _nodeFs.default.existsSync((0, _pathResolveC6Vj5eOM.a)(agentDir));
}
function hasAnyAuthProfileStoreSource(agentDir) {
  if ((0, _runtimeSnapshotsEsDr_mQ_.r)(agentDir)) return true;
  if (hasStoredAuthProfileFiles(agentDir)) return true;
  const authPath = (0, _pathResolveC6Vj5eOM.r)(agentDir);
  const mainAuthPath = (0, _pathResolveC6Vj5eOM.r)();
  if (agentDir && authPath !== mainAuthPath && hasStoredAuthProfileFiles(void 0)) return true;
  return false;
}
//#endregion /* v9-a80beaefd3920c10 */
