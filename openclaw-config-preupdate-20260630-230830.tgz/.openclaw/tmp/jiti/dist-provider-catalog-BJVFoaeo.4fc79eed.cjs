"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.t = buildTokenHubProvider;var _modelsNbkgAGHo = require("./models-NbkgAGHo.js");
//#region extensions/tencent/provider-catalog.ts
function buildTokenHubProvider() {
  return {
    baseUrl: _modelsNbkgAGHo.t,
    api: "openai-completions",
    models: _modelsNbkgAGHo.n.map(_modelsNbkgAGHo.i)
  };
}
//#endregion /* v9-52e0af97cc818913 */
