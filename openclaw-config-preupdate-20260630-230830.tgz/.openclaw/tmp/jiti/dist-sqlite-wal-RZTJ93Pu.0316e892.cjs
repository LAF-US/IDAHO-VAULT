"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.n = requireNodeSqlite;exports.t = configureSqliteWalMaintenance;var _errorsB3ZrCRlt = require("./errors-b3ZrCRlt.js");
var _warningFilterEk98bF5R = require("./warning-filter-Ek98bF5R.js");
var _nodeModule = require("node:module");
//#region src/infra/node-sqlite.ts
const _require = (0, _nodeModule.createRequire)("file:///Users/logan/.nvm/versions/node/v24.15.0/lib/node_modules/openclaw/dist/sqlite-wal-RZTJ93Pu.js");
function requireNodeSqlite() {
  (0, _warningFilterEk98bF5R.t)();
  try {
    return _require("node:sqlite");
  } catch (err) {
    const message = (0, _errorsB3ZrCRlt.i)(err);
    throw new Error(`SQLite support is unavailable in this Node runtime (missing node:sqlite). ${message}`, { cause: err });
  }
}
function normalizeNonNegativeInteger(value, label) {
  if (!Number.isInteger(value) || value < 0) throw new Error(`${label} must be a non-negative integer`);
  return value;
}
function configureSqliteWalMaintenance(db, options = {}) {
  const autoCheckpointPages = normalizeNonNegativeInteger(options.autoCheckpointPages ?? 1e3, "autoCheckpointPages");
  const checkpointIntervalMs = normalizeNonNegativeInteger(options.checkpointIntervalMs ?? 18e5, "checkpointIntervalMs");
  const checkpointMode = options.checkpointMode ?? "TRUNCATE";
  db.exec("PRAGMA journal_mode = WAL;");
  db.exec(`PRAGMA wal_autocheckpoint = ${autoCheckpointPages};`);
  const checkpoint = () => {
    try {
      db.exec(`PRAGMA wal_checkpoint(${checkpointMode});`);
      return true;
    } catch (error) {
      options.onCheckpointError?.(error);
      return false;
    }
  };
  let timer = null;
  if (checkpointIntervalMs > 0) {
    timer = setInterval(checkpoint, checkpointIntervalMs);
    timer.unref?.();
  }
  return {
    checkpoint,
    close: () => {
      if (timer) {
        clearInterval(timer);
        timer = null;
      }
      return checkpoint();
    }
  };
}
//#endregion /* v9-d5b156b4e5bf7c4e */
