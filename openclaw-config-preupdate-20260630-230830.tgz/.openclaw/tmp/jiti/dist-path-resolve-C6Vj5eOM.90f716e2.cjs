"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.a = resolveLegacyAuthStorePath;exports.c = void 0;exports.i = resolveAuthStorePathForDisplay;exports.l = void 0;exports.n = resolveAuthStatePathForDisplay;exports.o = resolveOAuthRefreshLockPath;exports.r = resolveAuthStorePath;exports.s = void 0;exports.t = resolveAuthStatePath;var _pathsCw7f9XhU = require("./paths-Cw7f9XhU.js");
var _utilsSBTEdeml = require("./utils-sBTEdeml.js");
var _agentScopeConfigCMp71_ = require("./agent-scope-config-CMp71_27.js");
var _nodePath = _interopRequireDefault(require("node:path"));
var _nodeCrypto = require("node:crypto");function _interopRequireDefault(e) {return e && e.__esModule ? e : { default: e };}
//#region src/agents/auth-profiles/path-constants.ts
const AUTH_PROFILE_FILENAME = exports.s = "auth-profiles.json";
const AUTH_STATE_FILENAME = exports.c = "auth-state.json";
const LEGACY_AUTH_FILENAME = exports.l = "auth.json";
//#endregion
//#region src/agents/auth-profiles/path-resolve.ts
function resolveAuthStorePath(agentDir) {
  const resolved = (0, _utilsSBTEdeml.p)(agentDir ?? (0, _agentScopeConfigCMp71_.s)({}));
  return _nodePath.default.join(resolved, AUTH_PROFILE_FILENAME);
}
function resolveLegacyAuthStorePath(agentDir) {
  const resolved = (0, _utilsSBTEdeml.p)(agentDir ?? (0, _agentScopeConfigCMp71_.s)({}));
  return _nodePath.default.join(resolved, LEGACY_AUTH_FILENAME);
}
function resolveAuthStatePath(agentDir) {
  const resolved = (0, _utilsSBTEdeml.p)(agentDir ?? (0, _agentScopeConfigCMp71_.s)({}));
  return _nodePath.default.join(resolved, AUTH_STATE_FILENAME);
}
function resolveAuthStorePathForDisplay(agentDir) {
  const pathname = resolveAuthStorePath(agentDir);
  return pathname.startsWith("~") ? pathname : (0, _utilsSBTEdeml.p)(pathname);
}
function resolveAuthStatePathForDisplay(agentDir) {
  const pathname = resolveAuthStatePath(agentDir);
  return pathname.startsWith("~") ? pathname : (0, _utilsSBTEdeml.p)(pathname);
}
/**
* Resolve the path of the cross-agent, per-profile OAuth refresh coordination
* lock. The filename hashes `provider\0profileId` so it is filesystem-safe
* for arbitrary unicode/control-character inputs and always bounded in
* length. The NUL separator makes it impossible to collide two distinct
* `(provider, profileId)` pairs by string concatenation.
*
* This lock is the serialization point that prevents the `refresh_token_reused`
* storm when N agents share one OAuth profile (see issue #26322): every agent
* that attempts a refresh acquires this same file lock, so only one HTTP
* refresh is in-flight at a time and peers can adopt the resulting fresh
* credentials instead of racing against a single-use refresh token.
*
* The key intentionally includes `provider` so that two profiles that
* happen to share a `profileId` across providers (operator-renamed profile,
* test fixture, etc.) do not needlessly serialize against each other.
*/
function resolveOAuthRefreshLockPath(provider, profileId) {
  const hash = (0, _nodeCrypto.createHash)("sha256");
  hash.update(provider, "utf8");
  hash.update("\0", "utf8");
  hash.update(profileId, "utf8");
  const safeId = `sha256-${hash.digest("hex")}`;
  return _nodePath.default.join((0, _pathsCw7f9XhU.y)(), "locks", "oauth-refresh", safeId);
}
//#endregion /* v9-4d34f2935e1ae646 */
