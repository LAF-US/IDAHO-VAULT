"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.n = getChannelPluginCatalogEntry;exports.r = listChannelPluginCatalogEntries;exports.t = buildChannelUiCatalog;var _stringCoerceBje8XVt = require("./string-coerce-Bje8XVt9.js");
var _openclawRootCRSCIPqz = require("./openclaw-root-CRSCIPqz.js");
var _utilsD5swhEXt = require("./utils-D5swhEXt.js");
var _legacyNamesB8PgFyB = require("./legacy-names-b8PgFyB2.js");
var _discoveryCVL9KJt = require("./discovery-CVL9-KJt.js");
var _channelCatalogRegistryCNXtcf4Q = require("./channel-catalog-registry-CNXtcf4Q.js");
var _installSourceInfoD4ewXUGX = require("./install-source-info-D4ewXUGX.js");
var _officialExternalPluginCatalog64MlR6o = require("./official-external-plugin-catalog--64MlR6o.js");
var _channelMetaBUHH6hK = require("./channel-meta-BU-HH6hK.js");
var _nodeFs = _interopRequireDefault(require("node:fs"));
var _nodePath = _interopRequireDefault(require("node:path"));function _interopRequireDefault(e) {return e && e.__esModule ? e : { default: e };}
//#region src/channels/plugins/catalog.ts
const ORIGIN_PRIORITY = {
  config: 0,
  workspace: 1,
  global: 2,
  bundled: 3
};
const EXTERNAL_CATALOG_PRIORITY = ORIGIN_PRIORITY.bundled + 1;
const FALLBACK_CATALOG_PRIORITY = EXTERNAL_CATALOG_PRIORITY + 1;
const ENV_CATALOG_PATHS = ["OPENCLAW_PLUGIN_CATALOG_PATHS", "OPENCLAW_MPM_CATALOG_PATHS"];
const OFFICIAL_CHANNEL_CATALOG_RELATIVE_PATH = _nodePath.default.join("dist", "channel-catalog.json");
const officialCatalogEntriesByPath = /* @__PURE__ */new Map();
function parseCatalogEntries(raw) {
  if (Array.isArray(raw)) return raw.filter((entry) => (0, _utilsD5swhEXt.c)(entry));
  if (!(0, _utilsD5swhEXt.c)(raw)) return [];
  const list = raw.entries ?? raw.packages ?? raw.plugins;
  if (!Array.isArray(list)) return [];
  return list.filter((entry) => (0, _utilsD5swhEXt.c)(entry));
}
function splitEnvPaths(value) {
  const trimmed = value.trim();
  if (!trimmed) return [];
  return trimmed.split(/[;,]/g).flatMap((chunk) => chunk.split(_nodePath.default.delimiter)).map((entry) => entry.trim()).filter(Boolean);
}
function resolveDefaultCatalogPaths(env) {
  const configDir = (0, _utilsD5swhEXt.d)(env);
  return [
  _nodePath.default.join(configDir, "mpm", "plugins.json"),
  _nodePath.default.join(configDir, "mpm", "catalog.json"),
  _nodePath.default.join(configDir, "plugins", "catalog.json")];

}
function resolveExternalCatalogPaths(options) {
  if (options.catalogPaths && options.catalogPaths.length > 0) return options.catalogPaths.map((entry) => entry.trim()).filter(Boolean);
  const env = options.env ?? process.env;
  for (const key of ENV_CATALOG_PATHS) {
    const raw = env[key];
    if (raw && raw.trim()) return splitEnvPaths(raw);
  }
  return resolveDefaultCatalogPaths(env);
}
function loadExternalCatalogEntries(options) {
  return loadCatalogEntriesFromPaths(resolveExternalCatalogPaths(options).map((rawPath) => (0, _utilsD5swhEXt.p)(rawPath, options.env ?? process.env)));
}
function loadCatalogEntriesFromPaths(paths) {
  const entries = [];
  for (const resolvedPath of paths) {
    if (!_nodeFs.default.existsSync(resolvedPath)) continue;
    try {
      const payload = JSON.parse(_nodeFs.default.readFileSync(resolvedPath, "utf-8"));
      entries.push(...parseCatalogEntries(payload));
    } catch {}
  }
  return entries;
}
function loadOfficialCatalogEntriesFromPaths(paths) {
  const entries = [];
  for (const resolvedPath of paths) {
    const cached = officialCatalogEntriesByPath.get(resolvedPath);
    if (cached !== void 0) {
      if (cached) entries.push(...cached);
      continue;
    }
    if (!_nodeFs.default.existsSync(resolvedPath)) {
      officialCatalogEntriesByPath.set(resolvedPath, null);
      continue;
    }
    try {
      const parsed = parseCatalogEntries(JSON.parse(_nodeFs.default.readFileSync(resolvedPath, "utf-8")));
      officialCatalogEntriesByPath.set(resolvedPath, parsed);
      entries.push(...parsed);
    } catch {
      officialCatalogEntriesByPath.set(resolvedPath, null);
    }
  }
  return entries;
}
function resolveOfficialCatalogPaths(options) {
  if (options.officialCatalogPaths && options.officialCatalogPaths.length > 0) return options.officialCatalogPaths.map((entry) => entry.trim()).filter(Boolean);
  const candidates = [(0, _openclawRootCRSCIPqz.n)({ cwd: process.cwd() }), (0, _openclawRootCRSCIPqz.n)({ moduleUrl: "file:///Users/logan/.nvm/versions/node/v24.15.0/lib/node_modules/openclaw/dist/catalog-DYcB5w-_.js" })].filter((entry, index, all) => Boolean(entry) && all.indexOf(entry) === index).map((packageRoot) => _nodePath.default.join(packageRoot, OFFICIAL_CHANNEL_CATALOG_RELATIVE_PATH));
  if (process.execPath) {
    const execDir = _nodePath.default.dirname(process.execPath);
    candidates.push(_nodePath.default.join(execDir, OFFICIAL_CHANNEL_CATALOG_RELATIVE_PATH));
    candidates.push(_nodePath.default.join(execDir, "channel-catalog.json"));
  }
  return candidates.filter((entry, index, all) => entry && all.indexOf(entry) === index);
}
function loadOfficialCatalogEntries(options) {
  const builtInEntries = (0, _officialExternalPluginCatalog64MlR6o.i)();
  const officialPaths = resolveOfficialCatalogPaths(options);
  const fileEntries = options.officialCatalogPaths && options.officialCatalogPaths.length > 0 ? loadCatalogEntriesFromPaths(officialPaths) : loadOfficialCatalogEntriesFromPaths(officialPaths);
  return [...builtInEntries, ...fileEntries].map((entry) => buildExternalCatalogEntry(entry, { trustedSourceLinkedOfficialInstall: true })).filter((entry) => Boolean(entry));
}
function toChannelMeta(params) {
  const label = params.channel.label?.trim();
  if (!label) return null;
  const selectionLabel = params.channel.selectionLabel?.trim() || label;
  const detailLabel = params.channel.detailLabel?.trim();
  const docsPath = params.channel.docsPath?.trim() || `/channels/${params.id}`;
  const blurb = params.channel.blurb?.trim() || "";
  const systemImage = params.channel.systemImage?.trim();
  return (0, _channelMetaBUHH6hK.t)({
    id: params.id,
    channel: params.channel,
    label,
    selectionLabel,
    docsPath,
    docsLabel: (0, _stringCoerceBje8XVt.c)(params.channel.docsLabel),
    blurb,
    detailLabel,
    ...(systemImage ? { systemImage } : {}),
    arrayFieldMode: "defined",
    selectionDocsPrefixMode: "truthy"
  });
}
function resolveInstallInfo(params) {
  const clawhubSpec = (0, _stringCoerceBje8XVt.c)(params.install?.clawhubSpec);
  let npmSpec = (0, _stringCoerceBje8XVt.c)(params.install?.npmSpec) ?? (0, _stringCoerceBje8XVt.c)(params.packageName);
  const packageVersion = (0, _stringCoerceBje8XVt.c)(params.packageVersion);
  const parsedNpmSpec = npmSpec ? (0, _discoveryCVL9KJt.F)(npmSpec) : null;
  const expectedPackageName = (0, _stringCoerceBje8XVt.c)(params.packageName);
  const parsedPackageName = expectedPackageName ? (0, _discoveryCVL9KJt.F)(expectedPackageName) : null;
  if (npmSpec && packageVersion && (0, _discoveryCVL9KJt.P)(packageVersion) && parsedNpmSpec?.selectorKind === "none" && (!parsedPackageName || parsedNpmSpec.name === parsedPackageName.name)) npmSpec = `${parsedNpmSpec.name}@${packageVersion}`;
  if (!clawhubSpec && !npmSpec) return null;
  let localPath = (0, _stringCoerceBje8XVt.c)(params.install?.localPath);
  if (!localPath && params.workspaceDir && params.packageDir) localPath = _nodePath.default.relative(params.workspaceDir, params.packageDir) || void 0;
  const requestedDefaultChoice = params.install?.defaultChoice;
  const defaultChoice = requestedDefaultChoice === "clawhub" && clawhubSpec ? "clawhub" : requestedDefaultChoice === "npm" && npmSpec ? "npm" : requestedDefaultChoice === "local" && localPath ? "local" : clawhubSpec ? "clawhub" : localPath ? "local" : "npm";
  const install = {
    ...(localPath ? { localPath } : {}),
    defaultChoice,
    ...(params.install?.minHostVersion ? { minHostVersion: params.install.minHostVersion } : {}),
    ...(params.install?.expectedIntegrity ? { expectedIntegrity: params.install.expectedIntegrity } : {}),
    ...(params.install?.allowInvalidConfigRecovery === true ? { allowInvalidConfigRecovery: true } : {})
  };
  if (clawhubSpec) return {
    clawhubSpec,
    ...(npmSpec ? { npmSpec } : {}),
    ...install
  };
  if (!npmSpec) return null;
  return {
    npmSpec,
    ...install
  };
}
function buildCatalogEntryFromManifest(params) {
  if (!params.channel) return null;
  const id = params.channel.id?.trim();
  if (!id) return null;
  const meta = toChannelMeta({
    channel: params.channel,
    id
  });
  if (!meta) return null;
  const install = resolveInstallInfo({
    install: params.install,
    packageName: params.packageName,
    packageVersion: params.packageVersion,
    packageDir: params.packageDir,
    workspaceDir: params.workspaceDir
  });
  if (!install) return null;
  const pluginId = (0, _stringCoerceBje8XVt.c)(params.pluginId);
  return {
    id,
    ...(pluginId ? { pluginId } : {}),
    ...(params.origin ? { origin: params.origin } : {}),
    ...(params.trustedSourceLinkedOfficialInstall ? { trustedSourceLinkedOfficialInstall: true } : {}),
    meta,
    install,
    installSource: (0, _installSourceInfoD4ewXUGX.t)(install, { expectedPackageName: params.packageName })
  };
}
function buildExternalCatalogEntry(entry, options) {
  const manifest = entry[_legacyNamesB8PgFyB.n];
  return buildCatalogEntryFromManifest({
    pluginId: manifest?.plugin?.id,
    packageName: entry.name,
    packageVersion: entry.version,
    trustedSourceLinkedOfficialInstall: options?.trustedSourceLinkedOfficialInstall,
    channel: manifest?.channel,
    install: manifest?.install
  });
}
function buildChannelUiCatalog(plugins) {
  const entries = plugins.map((plugin) => {
    const detailLabel = plugin.meta.detailLabel ?? plugin.meta.selectionLabel ?? plugin.meta.label;
    return {
      id: plugin.id,
      label: plugin.meta.label,
      detailLabel,
      ...(plugin.meta.systemImage ? { systemImage: plugin.meta.systemImage } : {})
    };
  });
  const order = entries.map((entry) => entry.id);
  const labels = {};
  const detailLabels = {};
  const systemImages = {};
  const byId = {};
  for (const entry of entries) {
    labels[entry.id] = entry.label;
    detailLabels[entry.id] = entry.detailLabel;
    if (entry.systemImage) systemImages[entry.id] = entry.systemImage;
    byId[entry.id] = entry;
  }
  return {
    entries,
    order,
    labels,
    detailLabels,
    systemImages,
    byId
  };
}
function listChannelPluginCatalogEntries(options = {}) {
  const manifestEntries = (0, _channelCatalogRegistryCNXtcf4Q.t)({
    workspaceDir: options.workspaceDir,
    env: options.env
  });
  const resolved = /* @__PURE__ */new Map();
  for (const candidate of manifestEntries) {
    if (options.excludeWorkspace && candidate.origin === "workspace") continue;
    const entry = buildCatalogEntryFromManifest({
      pluginId: candidate.pluginId,
      packageName: candidate.packageName,
      packageDir: candidate.rootDir,
      origin: candidate.origin,
      workspaceDir: candidate.workspaceDir ?? options.workspaceDir,
      channel: candidate.channel,
      install: candidate.install
    });
    if (!entry) continue;
    const priority = ORIGIN_PRIORITY[candidate.origin] ?? 99;
    const existing = resolved.get(entry.id);
    if (!existing || priority < existing.priority) resolved.set(entry.id, {
      entry,
      priority
    });
  }
  for (const entry of loadOfficialCatalogEntries(options)) {
    const priority = FALLBACK_CATALOG_PRIORITY;
    const existing = resolved.get(entry.id);
    if (!existing || priority < existing.priority) resolved.set(entry.id, {
      entry,
      priority
    });
  }
  const externalEntries = loadExternalCatalogEntries(options).map((entry) => buildExternalCatalogEntry(entry)).filter((entry) => Boolean(entry));
  for (const entry of externalEntries) {
    const priority = EXTERNAL_CATALOG_PRIORITY;
    const existing = resolved.get(entry.id);
    if (!existing || priority < existing.priority) resolved.set(entry.id, {
      entry,
      priority
    });
  }
  return Array.from(resolved.values()).map(({ entry }) => entry).toSorted((a, b) => {
    const orderA = a.meta.order ?? 999;
    const orderB = b.meta.order ?? 999;
    if (orderA !== orderB) return orderA - orderB;
    return a.meta.label.localeCompare(b.meta.label);
  });
}
function getChannelPluginCatalogEntry(id, options = {}) {
  const trimmed = id.trim();
  if (!trimmed) return;
  return listChannelPluginCatalogEntries(options).find((entry) => entry.id === trimmed);
}
//#endregion /* v9-f0f1563b7010853b */
