"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.a = resolveManifestOwnerBasePolicyBlock;exports.i = passesManifestOwnerBasePolicy;exports.n = isActivatedManifestOwner;exports.r = isBundledManifestOwner;exports.t = hasExplicitManifestOwnerTrust;var _configStateCjJBf8PG = require("./config-state-CjJBf8PG.js");
var _defaultEnablementCT7_t1ee = require("./default-enablement-CT7_t1ee.js");
//#region src/plugins/manifest-owner-policy.ts
function isBundledManifestOwner(plugin) {
  return plugin.origin === "bundled";
}
function hasExplicitManifestOwnerTrust(params) {
  return params.normalizedConfig.allow.includes(params.plugin.id) || params.normalizedConfig.entries[params.plugin.id]?.enabled === true;
}
function passesManifestOwnerBasePolicy(params) {
  return resolveManifestOwnerBasePolicyBlock(params) === null;
}
function resolveManifestOwnerBasePolicyBlock(params) {
  if (!params.normalizedConfig.enabled) return "plugins-disabled";
  if (params.normalizedConfig.deny.includes(params.plugin.id)) return "blocked-by-denylist";
  if (params.normalizedConfig.entries[params.plugin.id]?.enabled === false && params.allowExplicitlyDisabled !== true) return "plugin-disabled";
  if (params.allowRestrictiveAllowlistBypass !== true && params.normalizedConfig.allow.length > 0 && !params.normalizedConfig.allow.includes(params.plugin.id)) return "not-in-allowlist";
  return null;
}
function isActivatedManifestOwner(params) {
  return (0, _configStateCjJBf8PG.l)({
    id: params.plugin.id,
    origin: params.plugin.origin,
    config: params.normalizedConfig,
    rootConfig: params.rootConfig,
    enabledByDefault: (0, _defaultEnablementCT7_t1ee.t)(params.plugin)
  }).activated;
}
//#endregion /* v9-5cf9dc39234a0ff6 */
