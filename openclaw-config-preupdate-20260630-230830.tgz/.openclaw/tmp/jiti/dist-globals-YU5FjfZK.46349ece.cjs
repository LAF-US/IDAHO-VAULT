"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.a = shouldLogVerbose;exports.i = logVerboseConsole;exports.o = exports.n = void 0;exports.r = logVerbose;exports.t = exports.s = void 0;var _themeD58JpUfy = require("./theme-D58JpUfy.js");
var _globalStateBAD7XgmL = require("./global-state-BAD7XgmL.js");
var _loggerDg9dVaLI = require("./logger-Dg9dVaLI.js");
//#region src/globals.ts
function shouldLogVerbose() {
  return (0, _globalStateBAD7XgmL.t)() || (0, _loggerDg9dVaLI.o)("debug");
}
function logVerbose(message) {
  if (!shouldLogVerbose()) return;
  try {
    (0, _loggerDg9dVaLI.i)().debug({ message }, "verbose");
  } catch {}
  if (!(0, _globalStateBAD7XgmL.t)()) return;
  console.log(_themeD58JpUfy.r.muted(message));
}
function logVerboseConsole(message) {
  if (!(0, _globalStateBAD7XgmL.t)()) return;
  console.log(_themeD58JpUfy.r.muted(message));
}
const success = exports.o = _themeD58JpUfy.r.success;
const warn = exports.s = _themeD58JpUfy.r.warn;
const info = exports.n = _themeD58JpUfy.r.info;
const danger = exports.t = _themeD58JpUfy.r.error;
//#endregion /* v9-a88cd20200a7398e */
