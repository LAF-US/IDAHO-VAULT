"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.t = buildDeepSeekProvider;var _modelsCMCEiKpv = require("./models-CMCEiKpv.js");
//#region extensions/deepseek/provider-catalog.ts
function buildDeepSeekProvider() {
  return {
    baseUrl: _modelsCMCEiKpv.t,
    api: "openai-completions",
    models: _modelsCMCEiKpv.n.map(_modelsCMCEiKpv.r)
  };
}
//#endregion /* v9-5419f34335a15e64 */
