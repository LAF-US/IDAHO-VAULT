"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.t = normalizeChatType;var _stringCoerceDyL154ka = require("./string-coerce-DyL154ka.js");
//#region src/channels/chat-type.ts
function normalizeChatType(raw) {
  const value = (0, _stringCoerceDyL154ka.s)(raw);
  if (!value) return;
  if (value === "direct" || value === "dm") return "direct";
  if (value === "group") return "group";
  if (value === "channel") return "channel";
}
//#endregion /* v9-27b16521c52c52f4 */
