"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.t = resolveAgentHarnessPolicy;var _modelRuntimePolicyCAe5ww = require("./model-runtime-policy-CAe5ww09.js");
var _runtimeFVbSwiLb = require("./runtime-fVbSwiLb.js");
var _openaiCodexRoutingDwRY_VI = require("./openai-codex-routing-DwRY-_VI.js");
//#region src/agents/harness/policy.ts
function resolveAgentHarnessPolicy(params) {
  const configured = (0, _modelRuntimePolicyCAe5ww.t)({
    config: params.config,
    provider: params.provider,
    modelId: params.modelId,
    agentId: params.agentId,
    sessionKey: params.sessionKey
  });
  const configuredRuntime = configured.policy?.id?.trim();
  const runtimeSource = configured.source ?? "implicit";
  const runtime = configuredRuntime && configuredRuntime !== "default" ? (0, _runtimeFVbSwiLb.t)(configuredRuntime) : "auto";
  if ((0, _openaiCodexRoutingDwRY_VI.s)({
    provider: params.provider,
    config: params.config
  })) {
    if (runtime === "auto") return {
      runtime: "codex",
      runtimeSource
    };
    return {
      runtime,
      runtimeSource
    };
  }
  if ((0, _openaiCodexRoutingDwRY_VI.r)(params.provider)) {
    if (runtime === "auto") return {
      runtime: "codex",
      runtimeSource
    };
    return {
      runtime,
      runtimeSource
    };
  }
  return {
    runtime,
    runtimeSource
  };
}
//#endregion /* v9-8048599a2d8d6c72 */
