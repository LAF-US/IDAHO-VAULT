"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.default = void 0;var _providerCatalogDF5v1UBj = require("../../provider-catalog-DF5v1UBj.js");
//#region extensions/byteplus/provider-discovery.ts
const bytePlusProviderDiscovery = exports.default = [{
  id: "byteplus",
  label: "BytePlus",
  docsPath: "/providers/models",
  auth: [],
  staticCatalog: {
    order: "simple",
    run: async () => ({ provider: (0, _providerCatalogDF5v1UBj.n)() })
  }
}, {
  id: "byteplus-plan",
  label: "BytePlus Plan",
  docsPath: "/providers/models",
  auth: [],
  staticCatalog: {
    order: "simple",
    run: async () => ({ provider: (0, _providerCatalogDF5v1UBj.t)() })
  }
}];
//#endregion /* v9-5e36d5ed22658662 */
