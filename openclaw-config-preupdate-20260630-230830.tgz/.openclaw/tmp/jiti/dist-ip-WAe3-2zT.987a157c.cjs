"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports._ = parseLooseIpAddress;exports.a = isCarrierGradeNatIpv4Address;exports.c = isIpv4Address;exports.d = isLinkLocalIpAddress;exports.f = isLoopbackIpAddress;exports.g = parseCanonicalIpAddress;exports.h = normalizeIpAddress;exports.i = isCanonicalDottedDecimalIPv4;exports.l = isIpv6Address;exports.m = isRfc1918Ipv4Address;exports.n = isBlockedSpecialUseIpv4Address;exports.o = isCloudMetadataIpAddress;exports.p = isPrivateOrLoopbackIpAddress;exports.r = isBlockedSpecialUseIpv6Address;exports.s = isIpInCidr;exports.t = extractEmbeddedIpv4FromIpv6;exports.u = isLegacyIpv4Literal;var _stringCoerceDyL154ka = require("./string-coerce-DyL154ka.js");
var _ipaddr = _interopRequireDefault(require("ipaddr.js"));function _interopRequireDefault(e) {return e && e.__esModule ? e : { default: e };}
//#region src/shared/net/ip.ts
const BLOCKED_IPV4_SPECIAL_USE_RANGES = new Set([
"unspecified",
"broadcast",
"multicast",
"linkLocal",
"loopback",
"carrierGradeNat",
"private",
"reserved"]
);
const PRIVATE_OR_LOOPBACK_IPV4_RANGES = new Set([
"loopback",
"private",
"linkLocal",
"carrierGradeNat"]
);
const BLOCKED_IPV6_SPECIAL_USE_RANGES = new Set([
"unspecified",
"loopback",
"linkLocal",
"uniqueLocal",
"multicast",
"reserved",
"benchmarking",
"discard",
"orchid2"]
);
const RFC2544_BENCHMARK_PREFIX = [_ipaddr.default.IPv4.parse("198.18.0.0"), 15];
const CLOUD_METADATA_IP_ADDRESSES = new Set(["100.100.100.200", "fd00:ec2::254"]);
const EMBEDDED_IPV4_SENTINEL_RULES = [
{
  matches: (parts) => parts[0] === 0 && parts[1] === 0 && parts[2] === 0 && parts[3] === 0 && parts[4] === 0 && parts[5] === 0,
  toHextets: (parts) => [parts[6], parts[7]]
},
{
  matches: (parts) => parts[0] === 100 && parts[1] === 65435 && parts[2] === 1 && parts[3] === 0 && parts[4] === 0 && parts[5] === 0,
  toHextets: (parts) => [parts[6], parts[7]]
},
{
  matches: (parts) => parts[0] === 8194,
  toHextets: (parts) => [parts[1], parts[2]]
},
{
  matches: (parts) => parts[0] === 8193 && parts[1] === 0,
  toHextets: (parts) => [parts[6] ^ 65535, parts[7] ^ 65535]
},
{
  matches: (parts) => (parts[4] & 64767) === 0 && parts[5] === 24318,
  toHextets: (parts) => [parts[6], parts[7]]
}];

function stripIpv6Brackets(value) {
  if (value.startsWith("[") && value.endsWith("]")) return value.slice(1, -1);
  return value;
}
function isNumericIpv4LiteralPart(value) {
  return /^[0-9]+$/.test(value) || /^0x[0-9a-f]+$/i.test(value);
}
function parseIpv6WithEmbeddedIpv4(raw) {
  if (!raw.includes(":") || !raw.includes(".")) return;
  const match = /^(.*:)([^:%]+(?:\.[^:%]+){3})(%[0-9A-Za-z]+)?$/i.exec(raw);
  if (!match) return;
  const [, prefix, embeddedIpv4, zoneSuffix = ""] = match;
  if (!_ipaddr.default.IPv4.isValidFourPartDecimal(embeddedIpv4)) return;
  const octets = embeddedIpv4.split(".").map((part) => Number.parseInt(part, 10));
  const normalizedIpv6 = `${prefix}${(octets[0] << 8 | octets[1]).toString(16)}:${(octets[2] << 8 | octets[3]).toString(16)}${zoneSuffix}`;
  if (!_ipaddr.default.IPv6.isValid(normalizedIpv6)) return;
  return _ipaddr.default.IPv6.parse(normalizedIpv6);
}
function isIpv4Address(address) {
  return address.kind() === "ipv4";
}
function isIpv6Address(address) {
  return address.kind() === "ipv6";
}
function normalizeIpv4MappedAddress(address) {
  if (!isIpv6Address(address)) return address;
  if (!address.isIPv4MappedAddress()) return address;
  return address.toIPv4Address();
}
function normalizeIpParseInput(raw) {
  const trimmed = (0, _stringCoerceDyL154ka.c)(raw);
  if (!trimmed) return;
  return stripIpv6Brackets(trimmed);
}
function parseCanonicalIpAddress(raw) {
  const normalized = normalizeIpParseInput(raw);
  if (!normalized) return;
  if (_ipaddr.default.IPv4.isValid(normalized)) {
    if (!_ipaddr.default.IPv4.isValidFourPartDecimal(normalized)) return;
    return _ipaddr.default.IPv4.parse(normalized);
  }
  if (_ipaddr.default.IPv6.isValid(normalized)) return _ipaddr.default.IPv6.parse(normalized);
  return parseIpv6WithEmbeddedIpv4(normalized);
}
function parseLooseIpAddress(raw) {
  const normalized = normalizeIpParseInput(raw);
  if (!normalized) return;
  if (_ipaddr.default.isValid(normalized)) return _ipaddr.default.parse(normalized);
  return parseIpv6WithEmbeddedIpv4(normalized);
}
function normalizeIpAddress(raw) {
  const parsed = parseCanonicalIpAddress(raw);
  if (!parsed) return;
  return (0, _stringCoerceDyL154ka.a)(normalizeIpv4MappedAddress(parsed).toString());
}
function isCanonicalDottedDecimalIPv4(raw) {
  const trimmed = (0, _stringCoerceDyL154ka.c)(raw);
  if (!trimmed) return false;
  const normalized = stripIpv6Brackets(trimmed);
  if (!normalized) return false;
  return _ipaddr.default.IPv4.isValidFourPartDecimal(normalized);
}
function isLegacyIpv4Literal(raw) {
  const trimmed = (0, _stringCoerceDyL154ka.c)(raw);
  if (!trimmed) return false;
  const normalized = stripIpv6Brackets(trimmed);
  if (!normalized || normalized.includes(":")) return false;
  if (isCanonicalDottedDecimalIPv4(normalized)) return false;
  const parts = normalized.split(".");
  if (parts.length === 0 || parts.length > 4) return false;
  if (parts.some((part) => part.length === 0)) return false;
  if (!parts.every((part) => isNumericIpv4LiteralPart(part))) return false;
  return true;
}
function isLoopbackIpAddress(raw) {
  const parsed = parseCanonicalIpAddress(raw);
  if (!parsed) return false;
  return normalizeIpv4MappedAddress(parsed).range() === "loopback";
}
function isLinkLocalIpAddress(raw) {
  const parsed = parseLooseIpAddress(raw);
  if (!parsed) return false;
  const normalized = normalizeIpv4MappedAddress(parsed);
  if (isIpv4Address(normalized)) return normalized.range() === "linkLocal";
  if (extractEmbeddedIpv4FromIpv6(normalized)?.range() === "linkLocal") return true;
  return normalized.range() === "linkLocal";
}
function isCloudMetadataIpAddress(raw) {
  const parsed = parseLooseIpAddress(raw);
  if (!parsed) return false;
  const normalized = normalizeIpv4MappedAddress(parsed);
  if (isIpv6Address(normalized)) {
    const embeddedIpv4 = extractEmbeddedIpv4FromIpv6(normalized);
    if (embeddedIpv4 && CLOUD_METADATA_IP_ADDRESSES.has(embeddedIpv4.toString())) return true;
  }
  return CLOUD_METADATA_IP_ADDRESSES.has(normalized.toString());
}
function isPrivateOrLoopbackIpAddress(raw) {
  const parsed = parseCanonicalIpAddress(raw);
  if (!parsed) return false;
  const normalized = normalizeIpv4MappedAddress(parsed);
  if (isIpv4Address(normalized)) return PRIVATE_OR_LOOPBACK_IPV4_RANGES.has(normalized.range());
  return isBlockedSpecialUseIpv6Address(normalized);
}
function isBlockedSpecialUseIpv6Address(address, options = {}) {
  const range = address.range();
  if (range === "uniqueLocal" && options.allowUniqueLocalRange === true) return false;
  if (BLOCKED_IPV6_SPECIAL_USE_RANGES.has(range)) return true;
  return (address.parts[0] & 65472) === 65216;
}
function isRfc1918Ipv4Address(raw) {
  const parsed = parseCanonicalIpAddress(raw);
  if (!parsed || !isIpv4Address(parsed)) return false;
  return parsed.range() === "private";
}
function isCarrierGradeNatIpv4Address(raw) {
  const parsed = parseCanonicalIpAddress(raw);
  if (!parsed || !isIpv4Address(parsed)) return false;
  return parsed.range() === "carrierGradeNat";
}
function isBlockedSpecialUseIpv4Address(address, options = {}) {
  const inRfc2544BenchmarkRange = address.match(RFC2544_BENCHMARK_PREFIX);
  if (inRfc2544BenchmarkRange && options.allowRfc2544BenchmarkRange === true) return false;
  return BLOCKED_IPV4_SPECIAL_USE_RANGES.has(address.range()) || inRfc2544BenchmarkRange;
}
function decodeIpv4FromHextets(high, low) {
  const octets = [
  high >>> 8 & 255,
  high & 255,
  low >>> 8 & 255,
  low & 255];

  return _ipaddr.default.IPv4.parse(octets.join("."));
}
function extractEmbeddedIpv4FromIpv6(address) {
  if (address.isIPv4MappedAddress()) return address.toIPv4Address();
  if (address.range() === "rfc6145") return decodeIpv4FromHextets(address.parts[6], address.parts[7]);
  if (address.range() === "rfc6052") return decodeIpv4FromHextets(address.parts[6], address.parts[7]);
  for (const rule of EMBEDDED_IPV4_SENTINEL_RULES) {
    if (!rule.matches(address.parts)) continue;
    const [high, low] = rule.toHextets(address.parts);
    return decodeIpv4FromHextets(high, low);
  }
}
function isIpInCidr(ip, cidr) {
  const normalizedIp = parseCanonicalIpAddress(ip);
  if (!normalizedIp) return false;
  const candidate = cidr.trim();
  if (!candidate) return false;
  const comparableIp = normalizeIpv4MappedAddress(normalizedIp);
  if (!candidate.includes("/")) {
    const exact = parseCanonicalIpAddress(candidate);
    if (!exact) return false;
    const comparableExact = normalizeIpv4MappedAddress(exact);
    return comparableIp.kind() === comparableExact.kind() && comparableIp.toString() === comparableExact.toString();
  }
  let parsedCidr;
  try {
    parsedCidr = _ipaddr.default.parseCIDR(candidate);
  } catch {
    return false;
  }
  const [baseAddress, prefixLength] = parsedCidr;
  const comparableBase = normalizeIpv4MappedAddress(baseAddress);
  if (comparableIp.kind() !== comparableBase.kind()) return false;
  try {
    if (isIpv4Address(comparableIp) && isIpv4Address(comparableBase)) return comparableIp.match([comparableBase, prefixLength]);
    if (isIpv6Address(comparableIp) && isIpv6Address(comparableBase)) return comparableIp.match([comparableBase, prefixLength]);
    return false;
  } catch {
    return false;
  }
}
//#endregion /* v9-6ccf21c79c7bf90e */
