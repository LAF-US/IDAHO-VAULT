"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.n = resolveEffectiveAgentSkillsLimits;exports.t = resolveEffectiveAgentSkillFilter;var _sessionKeyBte0mmcq = require("./session-key-Bte0mmcq.js");
var _filterCuPfbjn = require("./filter-CuPfbjn1.js");
//#region src/agents/skills/agent-filter.ts
function resolveAgentEntry(cfg, agentId) {
  if (!cfg) return;
  const normalizedAgentId = (0, _sessionKeyBte0mmcq.l)(agentId);
  return cfg.agents?.list?.find((entry) => (0, _sessionKeyBte0mmcq.l)(entry.id) === normalizedAgentId);
}
/**
* Explicit per-agent skills win when present; otherwise fall back to shared defaults.
* Unknown agent ids also fall back to defaults so legacy/unresolved callers do not widen access.
*/
function resolveEffectiveAgentSkillFilter(cfg, agentId) {
  if (!cfg) return;
  const agentEntry = resolveAgentEntry(cfg, agentId);
  if (agentEntry && Object.hasOwn(agentEntry, "skills")) return (0, _filterCuPfbjn.n)(agentEntry.skills);
  return (0, _filterCuPfbjn.n)(cfg.agents?.defaults?.skills);
}
function resolveEffectiveAgentSkillsLimits(cfg, agentId) {
  if (!agentId) return;
  const agentEntry = resolveAgentEntry(cfg, agentId);
  if (!agentEntry || !Object.hasOwn(agentEntry, "skillsLimits")) return;
  const { maxSkillsPromptChars } = agentEntry.skillsLimits ?? {};
  return typeof maxSkillsPromptChars === "number" ? { maxSkillsPromptChars } : void 0;
}
//#endregion /* v9-3ffe718449065ec7 */
