"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.n = resolveSessionKey;exports.t = deriveSessionKey;var _stringCoerceDyL154ka = require("./string-coerce-DyL154ka.js");
var _utilsSBTEdeml = require("./utils-sBTEdeml.js");
var _sessionKeyUtilsCe_xWkNq = require("./session-key-utils-Ce_xWkNq.js");
var _sessionKeyBte0mmcq = require("./session-key-Bte0mmcq.js");
var _messageChannelCYCKkVrh = require("./message-channel-CYCKkVrh.js");
var _registryBf5TpUad = require("./registry-Bf5TpUad.js");
var _storeBmtchQvp = require("./store-BmtchQvp.js");
require("./plugins-DYTHbmt7.js");
//#region src/config/sessions/explicit-session-key-normalization.ts
function resolveExplicitSessionKeyNormalizerCandidates(sessionKey, ctx) {
  const normalizedProvider = (0, _stringCoerceDyL154ka.s)(ctx.Provider);
  const normalizedSurface = (0, _stringCoerceDyL154ka.s)(ctx.Surface);
  const normalizedFrom = (0, _stringCoerceDyL154ka.a)(ctx.From);
  const candidates = /* @__PURE__ */new Set();
  const maybeAdd = (value) => {
    const normalized = (0, _messageChannelCYCKkVrh.u)(value);
    if (normalized) candidates.add(normalized);
  };
  maybeAdd(normalizedSurface);
  maybeAdd(normalizedProvider);
  maybeAdd(normalizedFrom.split(":", 1)[0]);
  for (const plugin of (0, _registryBf5TpUad.i)()) {
    const pluginId = (0, _messageChannelCYCKkVrh.u)(plugin.id);
    if (!pluginId) continue;
    if (sessionKey.startsWith(`${pluginId}:`) || sessionKey.includes(`:${pluginId}:`)) candidates.add(pluginId);
  }
  return [...candidates];
}
function normalizeExplicitSessionKey(sessionKey, ctx) {
  const normalized = (0, _sessionKeyUtilsCe_xWkNq.o)(sessionKey);
  for (const channelId of resolveExplicitSessionKeyNormalizerCandidates(normalized, ctx)) {
    const normalize = (0, _registryBf5TpUad.n)(channelId)?.messaging?.normalizeExplicitSessionKey;
    const next = normalize?.({
      sessionKey: normalized,
      ctx
    });
    if (typeof next === "string" && next.trim()) return (0, _sessionKeyUtilsCe_xWkNq.o)(next);
  }
  return normalized;
}
//#endregion
//#region src/config/sessions/session-key.ts
function deriveSessionKey(scope, ctx) {
  if (scope === "global") return "global";
  const resolvedGroup = (0, _storeBmtchQvp.b)(ctx);
  if (resolvedGroup) return resolvedGroup.key;
  return (ctx.From ? (0, _utilsSBTEdeml.l)(ctx.From) : "") || "unknown";
}
/**
* Resolve the session key with a canonical direct-chat bucket (default: "main").
* All non-group direct chats collapse to this bucket; groups stay isolated.
*/
function resolveSessionKey(scope, ctx, mainKey, agentId = _sessionKeyBte0mmcq.t) {
  const explicit = ctx.SessionKey?.trim();
  if (explicit) return normalizeExplicitSessionKey(explicit, ctx);
  const raw = deriveSessionKey(scope, ctx);
  if (scope === "global") return raw;
  const canonicalAgentId = (0, _sessionKeyBte0mmcq.l)(agentId);
  const canonical = (0, _sessionKeyBte0mmcq.r)({
    agentId: canonicalAgentId,
    mainKey: (0, _sessionKeyBte0mmcq.u)(mainKey)
  });
  if (!(raw.includes(":group:") || raw.includes(":channel:"))) return canonical;
  return `agent:${canonicalAgentId}:${raw}`;
}
//#endregion /* v9-209763b6818edf56 */
