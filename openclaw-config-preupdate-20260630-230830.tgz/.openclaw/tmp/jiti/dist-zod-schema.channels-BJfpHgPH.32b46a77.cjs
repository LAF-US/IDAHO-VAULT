"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.t = exports.r = exports.n = exports.i = void 0;var _schemasDel5uzR = require("./schemas-Del5uzR8.js");
//#region src/config/zod-schema.approvals.ts
const NativeExecApprovalEnableModeSchema = exports.i = (0, _schemasDel5uzR.Xn)([(0, _schemasDel5uzR.At)(), (0, _schemasDel5uzR.dn)("auto")]);
const ExecApprovalForwardTargetSchema = (0, _schemasDel5uzR.Tn)({
  channel: (0, _schemasDel5uzR.Rn)().min(1),
  to: (0, _schemasDel5uzR.Rn)().min(1),
  accountId: (0, _schemasDel5uzR.Rn)().optional(),
  threadId: (0, _schemasDel5uzR.Xn)([(0, _schemasDel5uzR.Rn)(), (0, _schemasDel5uzR.wn)()]).optional()
}).strict();
const ExecApprovalForwardingSchema = (0, _schemasDel5uzR.Tn)({
  enabled: (0, _schemasDel5uzR.At)().optional(),
  mode: (0, _schemasDel5uzR.Xn)([
  (0, _schemasDel5uzR.dn)("session"),
  (0, _schemasDel5uzR.dn)("targets"),
  (0, _schemasDel5uzR.dn)("both")]
  ).optional(),
  agentFilter: (0, _schemasDel5uzR.Et)((0, _schemasDel5uzR.Rn)()).optional(),
  sessionFilter: (0, _schemasDel5uzR.Et)((0, _schemasDel5uzR.Rn)()).optional(),
  targets: (0, _schemasDel5uzR.Et)(ExecApprovalForwardTargetSchema).optional()
}).strict().optional();
const ApprovalsSchema = exports.r = (0, _schemasDel5uzR.Tn)({
  exec: ExecApprovalForwardingSchema,
  plugin: ExecApprovalForwardingSchema
}).strict().optional();
//#endregion
//#region src/config/zod-schema.channels.ts
const ChannelHeartbeatVisibilitySchema = exports.n = (0, _schemasDel5uzR.Tn)({
  showOk: (0, _schemasDel5uzR.At)().optional(),
  showAlerts: (0, _schemasDel5uzR.At)().optional(),
  useIndicator: (0, _schemasDel5uzR.At)().optional()
}).strict().optional();
const ChannelHealthMonitorSchema = exports.t = (0, _schemasDel5uzR.Tn)({ enabled: (0, _schemasDel5uzR.At)().optional() }).strict().optional();
//#endregion /* v9-8b69f7911d67cb0e */
