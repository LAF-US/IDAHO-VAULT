"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.n = readClaudeCliCredentialsForSetup;exports.r = readClaudeCliCredentialsForSetupNonInteractive;exports.t = readClaudeCliCredentialsForRuntime;var _storeBMQkMM4l = require("./store-BMQkMM4l.js");
require("./provider-auth-BtRKd5us.js");
//#region extensions/anthropic/cli-auth-seam.ts
function readClaudeCliCredentialsForSetup() {
  return (0, _storeBMQkMM4l.F)();
}
function readClaudeCliCredentialsForSetupNonInteractive() {
  return (0, _storeBMQkMM4l.F)({ allowKeychainPrompt: false });
}
function readClaudeCliCredentialsForRuntime() {
  return (0, _storeBMQkMM4l.F)({ allowKeychainPrompt: false });
}
//#endregion /* v9-be96aa13b232dd9a */
