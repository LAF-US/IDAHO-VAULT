"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.a = isOperatorUiClient;exports.c = isGatewayMessageChannel;exports.d = resolveGatewayMessageChannel;exports.f = resolveMessageChannel;exports.i = isMarkdownCapableMessageChannel;exports.l = void 0;exports.n = isGatewayCliClient;exports.o = isWebchatClient;exports.r = isInternalMessageChannel;exports.s = isDeliverableMessageChannel;exports.t = isBrowserOperatorUiClient;exports.u = normalizeMessageChannel;var _idsBE_yccbC = require("./ids-BE_yccbC.js");
var _chatMeta2H4wOcrq = require("./chat-meta-2H4wOcrq.js");
var _registryCtWyD2pE = require("./registry-CtWyD2pE.js");
var _clientInfoBVWE_ra = require("./client-info-BVWE_ra1.js");
var _messageChannelCoreBoUoCGOD = require("./message-channel-core-BoUoCGOD.js");
//#region src/utils/message-channel-normalize.ts
function normalizeMessageChannel(raw) {
  return (0, _messageChannelCoreBoUoCGOD.n)(raw);
}
const listPluginChannelIds = () => {
  return (0, _registryCtWyD2pE.i)();
};
const listDeliverableMessageChannels = () => Array.from(new Set([..._idsBE_yccbC.t, ...listPluginChannelIds()]));exports.l = listDeliverableMessageChannels;
const listGatewayMessageChannels = () => [...listDeliverableMessageChannels(), _messageChannelCoreBoUoCGOD.r];
function isGatewayMessageChannel(value) {
  return listGatewayMessageChannels().includes(value);
}
function isDeliverableMessageChannel(value) {
  return listDeliverableMessageChannels().includes(value);
}
function resolveGatewayMessageChannel(raw) {
  const normalized = normalizeMessageChannel(raw);
  if (!normalized) return;
  return isGatewayMessageChannel(normalized) ? normalized : void 0;
}
function resolveMessageChannel(primary, fallback) {
  return normalizeMessageChannel(primary) ?? normalizeMessageChannel(fallback);
}
//#endregion
//#region src/utils/message-channel.ts
function isGatewayCliClient(client) {
  return (0, _clientInfoBVWE_ra.s)(client?.mode) === _clientInfoBVWE_ra.r.CLI;
}
function isOperatorUiClient(client) {
  const clientId = (0, _clientInfoBVWE_ra.c)(client?.id);
  return clientId === _clientInfoBVWE_ra.i.CONTROL_UI || clientId === _clientInfoBVWE_ra.i.TUI;
}
function isBrowserOperatorUiClient(client) {
  return (0, _clientInfoBVWE_ra.c)(client?.id) === _clientInfoBVWE_ra.i.CONTROL_UI;
}
function isInternalMessageChannel(raw) {
  return normalizeMessageChannel(raw) === _messageChannelCoreBoUoCGOD.r;
}
function isWebchatClient(client) {
  if ((0, _clientInfoBVWE_ra.s)(client?.mode) === _clientInfoBVWE_ra.r.WEBCHAT) return true;
  return (0, _clientInfoBVWE_ra.c)(client?.id) === _clientInfoBVWE_ra.i.WEBCHAT_UI;
}
function isMarkdownCapableMessageChannel(raw) {
  const channel = normalizeMessageChannel(raw);
  if (!channel) return false;
  if (channel === "webchat" || channel === "tui") return true;
  const builtInChannel = (0, _idsBE_yccbC.r)(channel);
  if (builtInChannel) return (0, _chatMeta2H4wOcrq.t)(builtInChannel).markdownCapable === true;
  return (0, _registryCtWyD2pE.r)(channel)?.markdownCapable === true;
}
//#endregion /* v9-bfc69a091f5a13c9 */
