"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.t = ensureAuthStoreFile;var _jsonFileDpLhTVdZ = require("./json-file-DpLhTVdZ.js");
require("./path-resolve-C6Vj5eOM.js");
require("./constants-D_82oc2f.js");
var _nodeFs = _interopRequireDefault(require("node:fs"));function _interopRequireDefault(e) {return e && e.__esModule ? e : { default: e };}
//#region src/agents/auth-profiles/paths.ts
function ensureAuthStoreFile(pathname) {
  if (_nodeFs.default.existsSync(pathname)) return;
  (0, _jsonFileDpLhTVdZ.n)(pathname, {
    version: 1,
    profiles: {}
  });
}
//#endregion /* v9-d355b701bb61a549 */
