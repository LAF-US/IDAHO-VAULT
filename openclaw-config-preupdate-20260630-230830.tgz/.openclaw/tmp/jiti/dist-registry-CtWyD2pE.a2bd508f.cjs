"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.a = normalizeAnyChannelId;exports.i = listRegisteredChannelPluginIds;exports.n = formatChannelSelectionLine;exports.o = normalizeChannelId;exports.r = getRegisteredChannelPluginMeta;exports.t = formatChannelPrimerLine;var _stringCoerceDyL154ka = require("./string-coerce-DyL154ka.js");
var _idsBE_yccbC = require("./ids-BE_yccbC.js");
require("./chat-meta-2H4wOcrq.js");
var _registryLookupCxRGF57q = require("./registry-lookup-CxRGF57q.js");
//#region src/channels/registry.ts
function normalizeChannelId(raw) {
  return (0, _idsBE_yccbC.r)(raw);
}
function normalizeAnyChannelId(raw) {
  const key = (0, _stringCoerceDyL154ka.s)(raw);
  if (!key) return null;
  return (0, _registryLookupCxRGF57q.t)(key)?.plugin.id ?? null;
}
function listRegisteredChannelPluginIds() {
  return (0, _registryLookupCxRGF57q.r)().flatMap((entry) => {
    const id = (0, _stringCoerceDyL154ka.c)(entry.plugin.id);
    return id ? [id] : [];
  });
}
function getRegisteredChannelPluginMeta(id) {
  return (0, _registryLookupCxRGF57q.n)(id)?.plugin.meta ?? null;
}
function formatChannelPrimerLine(meta) {
  return `${meta.label}: ${meta.blurb}`;
}
function formatChannelSelectionLine(meta, docsLink) {
  const docsPrefix = meta.selectionDocsPrefix ?? "Docs:";
  const docsLabel = meta.docsLabel ?? meta.id;
  const docs = meta.selectionDocsOmitLabel ? docsLink(meta.docsPath) : docsLink(meta.docsPath, docsLabel);
  const extras = (meta.selectionExtras ?? []).filter(Boolean).join(" ");
  return `${meta.label} — ${meta.blurb} ${docsPrefix ? `${docsPrefix} ` : ""}${docs}${extras ? ` ${extras}` : ""}`;
}
//#endregion /* v9-e362d6eb35f2e160 */
