"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.i = resolvePluginRuntimeLoadContext;exports.n = buildPluginRuntimeLoadOptionsFromValues;exports.r = createPluginRuntimeLoaderLogger;exports.t = buildPluginRuntimeLoadOptions;require("./agent-scope-CtLXGcWm.js");
var _agentScopeConfigCMp71_ = require("./agent-scope-config-CMp71_27.js");
var _pluginMetadataSnapshotC_V3F5M = require("./plugin-metadata-snapshot-C-_V3F5M.js");
var _installedPluginIndexStoreC1Oen9wR = require("./installed-plugin-index-store-C1Oen9wR.js");
var _pluginRegistryCgH_ZSlH = require("./plugin-registry-CgH_ZSlH.js");
var _subsystemDSPWLoK = require("./subsystem-DSPWLoK5.js");
var _ioDoswVvYe = require("./io-DoswVvYe.js");
require("./config-B6Oplu5W.js");
var _pluginAutoEnableCuCUT4Z = require("./plugin-auto-enable-CuCUT4Z1.js");
var _loaderDKK7Ita = require("./loader-DKK7Ita0.js");
require("./logging-B2Kt4cNB.js");
//#region src/plugins/runtime/load-context.ts
const log = (0, _subsystemDSPWLoK.t)("plugins");
function createPluginRuntimeLoaderLogger() {
  return {
    info: (message) => log.info(message),
    warn: (message) => log.warn(message),
    error: (message) => log.error(message),
    debug: (message) => log.debug(message)
  };
}
function resolvePluginRuntimeLoadContext(options) {
  const env = options?.env ?? process.env;
  const rawConfig = options?.config ?? (0, _ioDoswVvYe.i)();
  const rawWorkspaceDir = options?.workspaceDir ?? (0, _agentScopeConfigCMp71_.o)(rawConfig, (0, _agentScopeConfigCMp71_.c)(rawConfig));
  const metadataSnapshot = options?.manifestRegistry ? void 0 : (0, _pluginRegistryCgH_ZSlH.v)({
    config: rawConfig,
    env,
    workspaceDir: rawWorkspaceDir
  }) ?? (0, _pluginMetadataSnapshotC_V3F5M.i)({
    config: rawConfig,
    env,
    workspaceDir: rawWorkspaceDir
  });
  const manifestRegistry = options?.manifestRegistry ?? metadataSnapshot?.manifestRegistry;
  const installRecords = metadataSnapshot ? (0, _installedPluginIndexStoreC1Oen9wR.h)(metadataSnapshot.index) : void 0;
  const activationSourceConfig = (0, _loaderDKK7Ita.O)({
    config: rawConfig,
    activationSourceConfig: options?.activationSourceConfig
  });
  const autoEnabled = (0, _pluginAutoEnableCuCUT4Z.t)({
    config: rawConfig,
    env,
    manifestRegistry
  });
  const config = autoEnabled.config;
  const workspaceDir = options?.workspaceDir ?? (0, _agentScopeConfigCMp71_.o)(config, (0, _agentScopeConfigCMp71_.c)(config));
  if (metadataSnapshot) if ((0, _pluginRegistryCgH_ZSlH.y)(metadataSnapshot)) (0, _pluginRegistryCgH_ZSlH.x)(metadataSnapshot, {
    config: rawConfig,
    compatibleConfigs: [config, activationSourceConfig],
    env,
    workspaceDir
  });else
  (0, _pluginRegistryCgH_ZSlH._)();
  return {
    rawConfig,
    config,
    activationSourceConfig,
    autoEnabledReasons: autoEnabled.autoEnabledReasons,
    workspaceDir,
    env,
    logger: options?.logger ?? createPluginRuntimeLoaderLogger(),
    ...(manifestRegistry ? { manifestRegistry } : {}),
    installRecords
  };
}
function buildPluginRuntimeLoadOptions(context, overrides) {
  return buildPluginRuntimeLoadOptionsFromValues(context, overrides);
}
function buildPluginRuntimeLoadOptionsFromValues(values, overrides) {
  return {
    config: values.config,
    activationSourceConfig: values.activationSourceConfig,
    autoEnabledReasons: values.autoEnabledReasons,
    workspaceDir: values.workspaceDir,
    env: values.env,
    logger: values.logger,
    ...(values.manifestRegistry ? { manifestRegistry: values.manifestRegistry } : {}),
    installRecords: values.installRecords,
    ...overrides
  };
}
//#endregion /* v9-17d537eb863d2d2b */
