"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.n = readCachedAuthProfileStore;exports.r = writeCachedAuthProfileStore;exports.t = clearLoadedAuthStoreCache;var _runtimeSnapshotsEsDr_mQ_ = require("./runtime-snapshots-esDr_mQ_.js");
require("./constants-D_82oc2f.js");
//#region src/agents/auth-profiles/store-cache.ts
const loadedAuthStoreCache = /* @__PURE__ */new Map();
function readCachedAuthProfileStore(params) {
  const cached = loadedAuthStoreCache.get(params.authPath);
  if (!cached || cached.authMtimeMs !== params.authMtimeMs || cached.stateMtimeMs !== params.stateMtimeMs) return null;
  if (Date.now() - cached.syncedAtMs >= 9e5) return null;
  return (0, _runtimeSnapshotsEsDr_mQ_.s)(cached.store);
}
function writeCachedAuthProfileStore(params) {
  loadedAuthStoreCache.set(params.authPath, {
    authMtimeMs: params.authMtimeMs,
    stateMtimeMs: params.stateMtimeMs,
    syncedAtMs: Date.now(),
    store: (0, _runtimeSnapshotsEsDr_mQ_.s)(params.store)
  });
}
function clearLoadedAuthStoreCache() {
  loadedAuthStoreCache.clear();
}
//#endregion /* v9-ec9877f844b02741 */
