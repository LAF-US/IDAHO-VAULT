"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.a = resolveSecretRefValue;exports.i = resolveSecretRefString;exports.n = void 0;exports.o = resolveSecretRefValues;exports.r = isProviderScopedSecretResolutionError;exports.t = void 0;var _errorsB3ZrCRlt = require("./errors-b3ZrCRlt.js");
var _pathBlG8lhgR = require("./path-BlG8lhgR.js");
var _fsSafeCV86zY9G = require("./fs-safe-CV86zY9G.js");
var _permissionsYa3cPkFH = require("./permissions-ya3cPkFH.js");
var _utilsSBTEdeml = require("./utils-sBTEdeml.js");
var _sharedCv5g0_Ch = require("./shared-Cv5g0_Ch.js");
var _refContractD_h_G00C = require("./ref-contract-D_h_G00C.js");
require("./audit-fs-CBe_wA_B.js");
require("./scan-paths-BJFKmVji.js");
var _runWithConcurrency5cC57eDC = require("./run-with-concurrency-5cC57eDC.js");
var _jsonPointerBRH9eAOA = require("./json-pointer-BRH9eAOA.js");
var _nodePath = _interopRequireDefault(require("node:path"));
var _promises = _interopRequireDefault(require("node:fs/promises"));
var _nodeChild_process = require("node:child_process");function _interopRequireDefault(e) {return e && e.__esModule ? e : { default: e };}
//#region src/secrets/resolve.ts
const DEFAULT_PROVIDER_CONCURRENCY = 4;
const DEFAULT_MAX_REFS_PER_PROVIDER = 512;
const DEFAULT_MAX_BATCH_BYTES = 256 * 1024;
const DEFAULT_FILE_MAX_BYTES = 1024 * 1024;
const DEFAULT_FILE_TIMEOUT_MS = 5e3;
const DEFAULT_EXEC_TIMEOUT_MS = 5e3;
const DEFAULT_EXEC_MAX_OUTPUT_BYTES = 1024 * 1024;
const WINDOWS_ABS_PATH_PATTERN = /^[A-Za-z]:[\\/]/;
const WINDOWS_UNC_PATH_PATTERN = /^\\\\[^\\]+\\[^\\]+/;
var SecretProviderResolutionError = class extends Error {
  constructor(params) {
    super(params.message, params.cause !== void 0 ? { cause: params.cause } : void 0);
    this.scope = "provider";
    this.name = "SecretProviderResolutionError";
    this.source = params.source;
    this.provider = params.provider;
  }
};exports.t = SecretProviderResolutionError;
var SecretRefResolutionError = class extends Error {
  constructor(params) {
    super(params.message, params.cause !== void 0 ? { cause: params.cause } : void 0);
    this.scope = "ref";
    this.name = "SecretRefResolutionError";
    this.source = params.source;
    this.provider = params.provider;
    this.refId = params.refId;
  }
};exports.n = SecretRefResolutionError;
function isProviderScopedSecretResolutionError(value) {
  return value instanceof SecretProviderResolutionError;
}
function isSecretResolutionError(value) {
  return value instanceof SecretProviderResolutionError || value instanceof SecretRefResolutionError;
}
function providerResolutionError(params) {
  return new SecretProviderResolutionError(params);
}
function refResolutionError(params) {
  return new SecretRefResolutionError(params);
}
function throwUnknownProviderResolutionError(params) {
  if (isSecretResolutionError(params.err)) throw params.err;
  throw providerResolutionError({
    source: params.source,
    provider: params.provider,
    message: (0, _errorsB3ZrCRlt.i)(params.err),
    cause: params.err
  });
}
async function readFileStatOrThrow(pathname, label) {
  const stat = await (0, _permissionsYa3cPkFH.d)(pathname);
  if (!stat.ok) throw new Error(`${label} is not readable: ${pathname}`);
  if (stat.isDir) throw new Error(`${label} must be a file: ${pathname}`);
  return stat;
}
function isAbsolutePathname(value) {
  return _nodePath.default.isAbsolute(value) || WINDOWS_ABS_PATH_PATTERN.test(value) || WINDOWS_UNC_PATH_PATTERN.test(value);
}
function resolveResolutionLimits(config) {
  const resolution = config.secrets?.resolution;
  return {
    maxProviderConcurrency: (0, _sharedCv5g0_Ch.r)(resolution?.maxProviderConcurrency, DEFAULT_PROVIDER_CONCURRENCY),
    maxRefsPerProvider: (0, _sharedCv5g0_Ch.r)(resolution?.maxRefsPerProvider, DEFAULT_MAX_REFS_PER_PROVIDER),
    maxBatchBytes: (0, _sharedCv5g0_Ch.r)(resolution?.maxBatchBytes, DEFAULT_MAX_BATCH_BYTES)
  };
}
function toProviderKey(source, provider) {
  return `${source}:${provider}`;
}
function resolveConfiguredProvider(ref, config) {
  const providerConfig = config.secrets?.providers?.[ref.provider];
  if (!providerConfig) {
    if (ref.source === "env" && ref.provider === (0, _refContractD_h_G00C.l)(config, "env")) return { source: "env" };
    throw providerResolutionError({
      source: ref.source,
      provider: ref.provider,
      message: `Secret provider "${ref.provider}" is not configured (ref: ${ref.source}:${ref.provider}:${ref.id}).`
    });
  }
  if (providerConfig.source !== ref.source) throw providerResolutionError({
    source: ref.source,
    provider: ref.provider,
    message: `Secret provider "${ref.provider}" has source "${providerConfig.source}" but ref requests "${ref.source}".`
  });
  return providerConfig;
}
async function assertSecurePath(params) {
  if (!isAbsolutePathname(params.targetPath)) throw new Error(`${params.label} must be an absolute path.`);
  let effectivePath = params.targetPath;
  let stat = await readFileStatOrThrow(effectivePath, params.label);
  if (stat.isSymlink) {
    if (!params.allowSymlinkPath) throw new Error(`${params.label} must not be a symlink: ${effectivePath}`);
    try {
      effectivePath = await _promises.default.realpath(effectivePath);
    } catch {
      throw new Error(`${params.label} symlink target is not readable: ${params.targetPath}`);
    }
    if (!isAbsolutePathname(effectivePath)) throw new Error(`${params.label} resolved symlink target must be an absolute path.`);
    stat = await readFileStatOrThrow(effectivePath, params.label);
    if (stat.isSymlink) throw new Error(`${params.label} symlink target must not be a symlink: ${effectivePath}`);
  }
  if (params.trustedDirs && params.trustedDirs.length > 0) {
    if (!params.trustedDirs.map((entry) => (0, _utilsSBTEdeml.p)(entry)).some((dir) => (0, _pathBlG8lhgR.i)(dir, effectivePath))) throw new Error(`${params.label} is outside trustedDirs: ${effectivePath}`);
  }
  if (params.allowInsecurePath) return effectivePath;
  const perms = await (0, _permissionsYa3cPkFH.a)(effectivePath);
  if (!perms.ok) throw new Error(`${params.label} permissions could not be verified: ${effectivePath}`);
  const writableByOthers = perms.worldWritable || perms.groupWritable;
  const readableByOthers = perms.worldReadable || perms.groupReadable;
  if (writableByOthers || !params.allowReadableByOthers && readableByOthers) throw new Error(`${params.label} permissions are too open: ${effectivePath}`);
  if (process.platform === "win32" && perms.source === "unknown") throw new Error(`${params.label} ACL verification unavailable on Windows for ${effectivePath}. Set allowInsecurePath=true for this provider to bypass this check when the path is trusted.`);
  if (process.platform !== "win32" && typeof process.getuid === "function" && stat.uid != null) {
    const uid = process.getuid();
    if (stat.uid !== uid) throw new Error(`${params.label} must be owned by the current user (uid=${uid}): ${effectivePath}`);
  }
  return effectivePath;
}
async function readFileProviderPayload(params) {
  const cacheKey = params.providerName;
  const cache = params.cache;
  const cachedFilePayload = cache?.filePayloadByProvider?.get(cacheKey);
  if (cachedFilePayload) return await cachedFilePayload;
  const filePath = (0, _utilsSBTEdeml.p)(params.providerConfig.path);
  const readPromise = (async () => {
    const timeoutMs = (0, _sharedCv5g0_Ch.r)(params.providerConfig.timeoutMs, DEFAULT_FILE_TIMEOUT_MS);
    const maxBytes = (0, _sharedCv5g0_Ch.r)(params.providerConfig.maxBytes, DEFAULT_FILE_MAX_BYTES);
    try {
      const { buffer: payload } = await (0, _fsSafeCV86zY9G.s)({
        filePath,
        label: `secrets.providers.${params.providerName}.path`,
        io: {
          maxBytes,
          timeoutMs
        },
        permissions: { allowInsecure: params.providerConfig.allowInsecurePath }
      });
      const text = payload.toString("utf8").replace(/^\uFEFF/, "");
      if (params.providerConfig.mode === "singleValue") return text.replace(/\r?\n$/, "");
      const parsed = JSON.parse(text);
      if (!(0, _utilsSBTEdeml.c)(parsed)) throw new Error(`File provider "${params.providerName}" payload is not a JSON object.`);
      return parsed;
    } catch (error) {
      if (error instanceof _pathBlG8lhgR.m && error.code === "timeout") throw new Error(`File provider "${params.providerName}" timed out after ${timeoutMs}ms.`, { cause: error });
      throw error;
    }
  })();
  if (cache) {
    cache.filePayloadByProvider ??= /* @__PURE__ */new Map();
    cache.filePayloadByProvider.set(cacheKey, readPromise);
  }
  return await readPromise;
}
async function resolveEnvRefs(params) {
  const resolved = /* @__PURE__ */new Map();
  const allowlist = params.providerConfig.allowlist ? new Set(params.providerConfig.allowlist) : null;
  for (const ref of params.refs) {
    if (allowlist && !allowlist.has(ref.id)) throw refResolutionError({
      source: "env",
      provider: params.providerName,
      refId: ref.id,
      message: `Environment variable "${ref.id}" is not allowlisted in secrets.providers.${params.providerName}.allowlist.`
    });
    const envValue = params.env[ref.id];
    if (!(0, _sharedCv5g0_Ch.n)(envValue)) throw refResolutionError({
      source: "env",
      provider: params.providerName,
      refId: ref.id,
      message: `Environment variable "${ref.id}" is missing or empty.`
    });
    resolved.set(ref.id, envValue);
  }
  return resolved;
}
async function resolveFileRefs(params) {
  let payload;
  try {
    payload = await readFileProviderPayload({
      providerName: params.providerName,
      providerConfig: params.providerConfig,
      cache: params.cache
    });
  } catch (err) {
    throwUnknownProviderResolutionError({
      source: "file",
      provider: params.providerName,
      err
    });
  }
  const mode = params.providerConfig.mode ?? "json";
  const resolved = /* @__PURE__ */new Map();
  if (mode === "singleValue") {
    for (const ref of params.refs) {
      if (ref.id !== "value") throw refResolutionError({
        source: "file",
        provider: params.providerName,
        refId: ref.id,
        message: `singleValue file provider "${params.providerName}" expects ref id "${_refContractD_h_G00C.i}".`
      });
      resolved.set(ref.id, payload);
    }
    return resolved;
  }
  for (const ref of params.refs) try {
    resolved.set(ref.id, (0, _jsonPointerBRH9eAOA.n)(payload, ref.id, { onMissing: "throw" }));
  } catch (err) {
    throw refResolutionError({
      source: "file",
      provider: params.providerName,
      refId: ref.id,
      message: (0, _errorsB3ZrCRlt.i)(err),
      cause: err
    });
  }
  return resolved;
}
function isIgnorableStdinWriteError(error) {
  if (typeof error !== "object" || error === null || !("code" in error)) return false;
  const code = String(error.code);
  return code === "EPIPE" || code === "ERR_STREAM_DESTROYED";
}
async function runExecResolver(params) {
  return await new Promise((resolve, reject) => {
    const child = (0, _nodeChild_process.spawn)(params.command, params.args, {
      cwd: params.cwd,
      env: params.env,
      stdio: [
      "pipe",
      "pipe",
      "pipe"],

      shell: false,
      windowsHide: true
    });
    let settled = false;
    let stdout = "";
    let stderr = "";
    let timedOut = false;
    let noOutputTimedOut = false;
    let outputBytes = 0;
    let noOutputTimer = null;
    const timeoutTimer = setTimeout(() => {
      timedOut = true;
      child.kill("SIGKILL");
    }, params.timeoutMs);
    const clearTimers = () => {
      clearTimeout(timeoutTimer);
      if (noOutputTimer) {
        clearTimeout(noOutputTimer);
        noOutputTimer = null;
      }
    };
    const armNoOutputTimer = () => {
      if (noOutputTimer) clearTimeout(noOutputTimer);
      noOutputTimer = setTimeout(() => {
        noOutputTimedOut = true;
        child.kill("SIGKILL");
      }, params.noOutputTimeoutMs);
    };
    const append = (chunk, target) => {
      const text = typeof chunk === "string" ? chunk : chunk.toString("utf8");
      outputBytes += Buffer.byteLength(text, "utf8");
      if (outputBytes > params.maxOutputBytes) {
        child.kill("SIGKILL");
        if (!settled) {
          settled = true;
          clearTimers();
          reject(/* @__PURE__ */new Error(`Exec provider output exceeded maxOutputBytes (${params.maxOutputBytes}).`));
        }
        return;
      }
      if (target === "stdout") stdout += text;else
      stderr += text;
      armNoOutputTimer();
    };
    armNoOutputTimer();
    child.on("error", (error) => {
      if (settled) return;
      settled = true;
      clearTimers();
      reject(error);
    });
    child.stdout?.on("data", (chunk) => append(chunk, "stdout"));
    child.stderr?.on("data", (chunk) => append(chunk, "stderr"));
    child.on("close", (code, signal) => {
      if (settled) return;
      settled = true;
      clearTimers();
      resolve({
        stdout,
        stderr,
        code,
        signal,
        termination: noOutputTimedOut ? "no-output-timeout" : timedOut ? "timeout" : "exit"
      });
    });
    const handleStdinError = (error) => {
      if (isIgnorableStdinWriteError(error) || settled) return;
      settled = true;
      clearTimers();
      reject(error instanceof Error ? error : new Error(String(error)));
    };
    child.stdin?.on("error", handleStdinError);
    try {
      child.stdin?.end(params.input);
    } catch (error) {
      handleStdinError(error);
    }
  });
}
function parseExecValues(params) {
  const trimmed = params.stdout.trim();
  if (!trimmed) throw providerResolutionError({
    source: "exec",
    provider: params.providerName,
    message: `Exec provider "${params.providerName}" returned empty stdout.`
  });
  let parsed;
  if (!params.jsonOnly && params.ids.length === 1) try {
    parsed = JSON.parse(trimmed);
  } catch {
    return { [params.ids[0]]: trimmed };
  } else
  try {
    parsed = JSON.parse(trimmed);
  } catch {
    throw providerResolutionError({
      source: "exec",
      provider: params.providerName,
      message: `Exec provider "${params.providerName}" returned invalid JSON.`
    });
  }
  if (!(0, _utilsSBTEdeml.c)(parsed)) {
    if (!params.jsonOnly && params.ids.length === 1 && typeof parsed === "string") return { [params.ids[0]]: parsed };
    throw providerResolutionError({
      source: "exec",
      provider: params.providerName,
      message: `Exec provider "${params.providerName}" response must be an object.`
    });
  }
  if (parsed.protocolVersion !== 1) throw providerResolutionError({
    source: "exec",
    provider: params.providerName,
    message: `Exec provider "${params.providerName}" protocolVersion must be 1.`
  });
  const responseValues = parsed.values;
  if (!(0, _utilsSBTEdeml.c)(responseValues)) throw providerResolutionError({
    source: "exec",
    provider: params.providerName,
    message: `Exec provider "${params.providerName}" response missing "values".`
  });
  const responseErrors = (0, _utilsSBTEdeml.c)(parsed.errors) ? parsed.errors : null;
  const out = {};
  for (const id of params.ids) {
    if (responseErrors && id in responseErrors) {
      const entry = responseErrors[id];
      if ((0, _utilsSBTEdeml.c)(entry) && typeof entry.message === "string" && entry.message.trim()) throw refResolutionError({
        source: "exec",
        provider: params.providerName,
        refId: id,
        message: `Exec provider "${params.providerName}" failed for id "${id}" (${entry.message.trim()}).`
      });
      throw refResolutionError({
        source: "exec",
        provider: params.providerName,
        refId: id,
        message: `Exec provider "${params.providerName}" failed for id "${id}".`
      });
    }
    if (!(id in responseValues)) throw refResolutionError({
      source: "exec",
      provider: params.providerName,
      refId: id,
      message: `Exec provider "${params.providerName}" response missing id "${id}".`
    });
    out[id] = responseValues[id];
  }
  return out;
}
async function resolveExecRefs(params) {
  const ids = [...new Set(params.refs.map((ref) => ref.id))];
  if (ids.length > params.limits.maxRefsPerProvider) throw providerResolutionError({
    source: "exec",
    provider: params.providerName,
    message: `Exec provider "${params.providerName}" exceeded maxRefsPerProvider (${params.limits.maxRefsPerProvider}).`
  });
  const commandPath = (0, _utilsSBTEdeml.p)(params.providerConfig.command);
  let secureCommandPath;
  try {
    secureCommandPath = await assertSecurePath({
      targetPath: commandPath,
      label: `secrets.providers.${params.providerName}.command`,
      trustedDirs: params.providerConfig.trustedDirs,
      allowInsecurePath: params.providerConfig.allowInsecurePath,
      allowReadableByOthers: true,
      allowSymlinkPath: params.providerConfig.allowSymlinkCommand
    });
  } catch (err) {
    throwUnknownProviderResolutionError({
      source: "exec",
      provider: params.providerName,
      err
    });
  }
  const requestPayload = {
    protocolVersion: 1,
    provider: params.providerName,
    ids
  };
  const input = JSON.stringify(requestPayload);
  if (Buffer.byteLength(input, "utf8") > params.limits.maxBatchBytes) throw providerResolutionError({
    source: "exec",
    provider: params.providerName,
    message: `Exec provider "${params.providerName}" request exceeded maxBatchBytes (${params.limits.maxBatchBytes}).`
  });
  const childEnv = {};
  for (const key of params.providerConfig.passEnv ?? []) {
    const value = params.env[key];
    if (value !== void 0) childEnv[key] = value;
  }
  for (const [key, value] of Object.entries(params.providerConfig.env ?? {})) childEnv[key] = value;
  const timeoutMs = (0, _sharedCv5g0_Ch.r)(params.providerConfig.timeoutMs, DEFAULT_EXEC_TIMEOUT_MS);
  const noOutputTimeoutMs = (0, _sharedCv5g0_Ch.r)(params.providerConfig.noOutputTimeoutMs, timeoutMs);
  const maxOutputBytes = (0, _sharedCv5g0_Ch.r)(params.providerConfig.maxOutputBytes, DEFAULT_EXEC_MAX_OUTPUT_BYTES);
  const jsonOnly = params.providerConfig.jsonOnly ?? true;
  let result;
  try {
    result = await runExecResolver({
      command: secureCommandPath,
      args: params.providerConfig.args ?? [],
      cwd: _nodePath.default.dirname(secureCommandPath),
      env: childEnv,
      input,
      timeoutMs,
      noOutputTimeoutMs,
      maxOutputBytes
    });
  } catch (err) {
    throwUnknownProviderResolutionError({
      source: "exec",
      provider: params.providerName,
      err
    });
  }
  if (result.termination === "timeout") throw providerResolutionError({
    source: "exec",
    provider: params.providerName,
    message: `Exec provider "${params.providerName}" timed out after ${timeoutMs}ms.`
  });
  if (result.termination === "no-output-timeout") throw providerResolutionError({
    source: "exec",
    provider: params.providerName,
    message: `Exec provider "${params.providerName}" produced no output for ${noOutputTimeoutMs}ms.`
  });
  if (result.code !== 0) throw providerResolutionError({
    source: "exec",
    provider: params.providerName,
    message: `Exec provider "${params.providerName}" exited with code ${String(result.code)}.`
  });
  let values;
  try {
    values = parseExecValues({
      providerName: params.providerName,
      ids,
      stdout: result.stdout,
      jsonOnly
    });
  } catch (err) {
    throwUnknownProviderResolutionError({
      source: "exec",
      provider: params.providerName,
      err
    });
  }
  const resolved = /* @__PURE__ */new Map();
  for (const id of ids) resolved.set(id, values[id]);
  return resolved;
}
async function resolveProviderRefs(params) {
  try {
    if (params.providerConfig.source === "env") return await resolveEnvRefs({
      refs: params.refs,
      providerName: params.providerName,
      providerConfig: params.providerConfig,
      env: params.options.env ?? process.env
    });
    if (params.providerConfig.source === "file") return await resolveFileRefs({
      refs: params.refs,
      providerName: params.providerName,
      providerConfig: params.providerConfig,
      cache: params.options.cache
    });
    if (params.providerConfig.source === "exec") return await resolveExecRefs({
      refs: params.refs,
      providerName: params.providerName,
      providerConfig: params.providerConfig,
      env: params.options.env ?? process.env,
      limits: params.limits
    });
    throw providerResolutionError({
      source: params.source,
      provider: params.providerName,
      message: `Unsupported secret provider source "${String(params.providerConfig.source)}".`
    });
  } catch (err) {
    return throwUnknownProviderResolutionError({
      source: params.source,
      provider: params.providerName,
      err
    });
  }
}
async function resolveSecretRefValues(refs, options) {
  if (refs.length === 0) return /* @__PURE__ */new Map();
  const limits = resolveResolutionLimits(options.config);
  const uniqueRefs = /* @__PURE__ */new Map();
  for (const ref of refs) {
    const id = ref.id.trim();
    if (!id) throw new Error("Secret reference id is empty.");
    if (ref.source === "exec" && !(0, _refContractD_h_G00C.o)(id)) throw new Error(`${(0, _refContractD_h_G00C.a)()} (ref: ${ref.source}:${ref.provider}:${id}).`);
    uniqueRefs.set((0, _refContractD_h_G00C.u)(ref), {
      ...ref,
      id
    });
  }
  const grouped = /* @__PURE__ */new Map();
  for (const ref of uniqueRefs.values()) {
    const key = toProviderKey(ref.source, ref.provider);
    const existing = grouped.get(key);
    if (existing) {
      existing.refs.push(ref);
      continue;
    }
    grouped.set(key, {
      source: ref.source,
      providerName: ref.provider,
      refs: [ref]
    });
  }
  const taskResults = await (0, _runWithConcurrency5cC57eDC.t)({
    tasks: [...grouped.values()].map((group) => async () => {
      if (group.refs.length > limits.maxRefsPerProvider) throw providerResolutionError({
        source: group.source,
        provider: group.providerName,
        message: `Secret provider "${group.providerName}" exceeded maxRefsPerProvider (${limits.maxRefsPerProvider}).`
      });
      const providerConfig = resolveConfiguredProvider(group.refs[0], options.config);
      return {
        group,
        values: await resolveProviderRefs({
          refs: group.refs,
          source: group.source,
          providerName: group.providerName,
          providerConfig,
          options,
          limits
        })
      };
    }),
    limit: limits.maxProviderConcurrency,
    errorMode: "stop"
  });
  if (taskResults.hasError) throw taskResults.firstError;
  const resolved = /* @__PURE__ */new Map();
  for (const result of taskResults.results) for (const ref of result.group.refs) {
    if (!result.values.has(ref.id)) throw refResolutionError({
      source: result.group.source,
      provider: result.group.providerName,
      refId: ref.id,
      message: `Secret provider "${result.group.providerName}" did not return id "${ref.id}".`
    });
    resolved.set((0, _refContractD_h_G00C.u)(ref), result.values.get(ref.id));
  }
  return resolved;
}
async function resolveSecretRefValue(ref, options) {
  const cache = options.cache;
  const key = (0, _refContractD_h_G00C.u)(ref);
  const cachedResolvedValue = cache?.resolvedByRefKey?.get(key);
  if (cachedResolvedValue) return await cachedResolvedValue;
  const promise = (async () => {
    const resolved = await resolveSecretRefValues([ref], options);
    if (!resolved.has(key)) throw refResolutionError({
      source: ref.source,
      provider: ref.provider,
      refId: ref.id,
      message: `Secret reference "${key}" resolved to no value.`
    });
    return resolved.get(key);
  })();
  if (cache) {
    cache.resolvedByRefKey ??= /* @__PURE__ */new Map();
    cache.resolvedByRefKey.set(key, promise);
  }
  return await promise;
}
async function resolveSecretRefString(ref, options) {
  const resolved = await resolveSecretRefValue(ref, options);
  if (!(0, _sharedCv5g0_Ch.n)(resolved)) throw new Error(`Secret reference "${ref.source}:${ref.provider}:${ref.id}" resolved to a non-string or empty value.`);
  return resolved;
}
//#endregion /* v9-d368d6788f47b27e */
