"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.t = getLoadedChannelPluginForRead;var _stringCoerceDyL154ka = require("./string-coerce-DyL154ka.js");
var _runtimeChannelStateCQNj7c3E = require("./runtime-channel-state-CQNj7c3E.js");
//#region src/channels/plugins/registry-loaded-read.ts
function coerceLoadedChannelPlugin(plugin) {
  const id = (0, _stringCoerceDyL154ka.c)(plugin?.id) ?? "";
  if (!plugin || !id) return;
  if (!plugin.meta || typeof plugin.meta !== "object") plugin.meta = {};
  return plugin;
}
function getLoadedChannelPluginForRead(id) {
  const resolvedId = (0, _stringCoerceDyL154ka.c)(id) ?? "";
  if (!resolvedId) return;
  const registry = (0, _runtimeChannelStateCQNj7c3E.t)();
  if (!registry || !Array.isArray(registry.channels)) return;
  for (const entry of registry.channels) {
    const plugin = coerceLoadedChannelPlugin(entry?.plugin);
    if (plugin && plugin.id === resolvedId) return plugin;
  }
}
//#endregion /* v9-89dedb2d11c587fb */
